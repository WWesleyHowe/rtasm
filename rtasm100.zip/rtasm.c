/***********************************************************************************************
// Retargetable (RT) Cross-assembler
// Wesley Howe, W5ZZO 10-Apr-2023
// Supports CDP1802, MC6800, 6502 targets
// Use rtasm {source file} -T [1802|6800|6502] on command line to set target CPU
//
//  This comment block must appear in any source code that uses code presented
//  as whole or part of the Retargetable Cross-assembler source code.
//
//  This software is made available under the GNU GPL V3 license agreement.
*************************************************************************************************/
//
#include "rtasm.h"
//
int main(int argc, char *argv[]) {
  int ret=false;

  if(argc<=1) {printHelp(argv[0]); return(1);}                        // arg[0] (argc==1) is only the command-eEe program name
  csrcfname[0]=hexfname[0]=lstfname[0]=binfname[0]=inpfname[0]='\0';  // ensure this begin with empty name fields
  strcpy_s((char *)&targetName[0], MAX_TNAME, "1802");
  CF.targetVal=TARGET_6800;                                           // set a default target CPU
  for(int i=1; i<argc; i++) {                                        // this must start at 1 to skip over argv[0], which is the program name
    if((argv[i][0]!='-')&&(argv[i][0]!='/')) {                        // the rule is next the input file name must be presented with no intro switch
      strcpy_s((char *)&inpfname[0], MAX_FILE_NAME, argv[i]);         // without a source file, the program will be useless!
      continue;
    }
    if(((argv[i][0]=='-')||(argv[i][0]=='/'))&&((argv[i][1]=='l')||(argv[i][1]=='L'))) {  // make the listing to a file
      ++i;                                                                                // move to next argument: is a rule
      strcpy_s((char *)&lstfname[0], MAX_FILE_NAME, argv[i]);
      lstHandle=FileOpen(&lstfname[0], "w");
      continue;
    }
    if(((argv[i][0]=='-')||(argv[i][0]=='/'))&&((argv[i][1]=='b')||(argv[i][1]=='B'))) {  // make a bin output file
      ++i;                                      // move to next argument: is a rule
      strcpy_s((char *)&binfname[0], MAX_FILE_NAME, argv[i]);
      continue;
    }
    if(((argv[i][0]=='-')||(argv[i][0]=='/'))&&((argv[i][1]=='h')||(argv[i][1]=='H'))) {  // make a hex output file
      ++i;                                      // move to next argument: is a rule
      strcpy_s((char *)&hexfname[0], MAX_FILE_NAME, argv[i]);
      continue;
    }
    if(((argv[i][0]=='-')||(argv[i][0]=='/'))&&((argv[i][1]=='c')||(argv[i][1]=='C'))) {  // make a c-source output file
      ++i;                                      // move to next argument: is a rule
      strcpy_s((char *)&csrcfname[0], MAX_FILE_NAME, argv[i]);
      continue;
    }
    if(((argv[i][0]=='-')||(argv[i][0]=='/'))&&((argv[i][1]=='m')||(argv[i][1]=='M'))) {  // make a Motorola S-Rec file
      ++i;                                      // move to next argument: is a rule
      strcpy_s((char *)&srecfname[0], MAX_FILE_NAME, argv[i]);
      continue;
    }
    if(((argv[i][0]=='-')||(argv[i][0]=='/'))&&((argv[i][1]=='t')||(argv[i][1]=='T'))) {  // make a Motorola S-Rec file
      ++i;                                      // move to next argument: is a rule
      strcpy_s((char *)&targetName[0], MAX_TNAME, argv[i]);
      if(checkCpuTarget()) {return(1);}
      continue;
    }
    if(((argv[i][0]=='-')||(argv[i][0]=='/'))&&((argv[i][1]=='s')||(argv[i][1]=='S'))) {  // enable swapStar (make * location value)
      CF.starSwap=true;
      starSwapSet=true;
      continue;
    }
    if(((argv[i][0]=='-')||(argv[i][0]=='/'))&&((argv[i][1]=='n')||(argv[i][1]=='N'))) {  // enable symbol numbers (value) sorting
      sortNumbers=true;
      continue;
    }
    if(((argv[i][0]=='-')||(argv[i][0]=='/'))&&((argv[i][1]=='r')||(argv[i][1]=='R'))) {  // enable reverse order symbol sorting
      sortReverse=true;
      continue;
    }
    // more switches can go here
  }
  if(inpfname[0]=='\0') {printHelp(argv[0]); return(1);}
  setup();
  if((ret=Asm())!=false) {PRINTF("Asm() returned error %d\n", ret);}
  return(ret);
}
//
// Check if that target is defined and if so set the configuration to it. Or error out.
int checkCpuTarget() {
  for(int i=0; i<SIZEOF(TGT); i++) {
    if(!(strcmp((const char *)&TGT[i].targetName, (char *)&targetName[0]))) {
      CF.targetVal=TGT[i].targetVal;
      return(0);
      }
    }
  PRINTF("Target %s is not available.\n", &targetName[0]);
  return(1);
  }
//
void printHelp(char *pname) {PRINTF("Usage: %s [filename] {-l [listing filename]} {-b [binfilename]} {-h [hexfilename]} {-c [csourcefilename]}\n\
{-s [swap star]} {-n [sort by value]} {-r [reverse sort order]}\n", pname);}
//
// ====================================================================================================================
// These functions are collected here to make porting to other platforms with different file systems easier.
FILE *FileOpen(uchar *name, const char *mode) {
  FILE *hndl;

  fopen_s(&hndl, (char *)name, mode);
//  hndl=fopen((char *)name, mode);
  return(hndl);
  }
//
int FileGetS(uchar *buff, int nch, FILE *file) {
  char *ret;

  ret=fgets((char *)buff, nch, file);
  if(ret<=0) {return(false);}
	return(true);
}
//
int FilePutS(const uchar *src, int nch, FILE *file) {
	fwrite(src, 1, nch, file);
	return(nch);
}
//
int FileClose(FILE *file) {
	if(file!=NULL) {fclose(file);}
	return(0);
}
///// ===================================================================================================================
//
void setup(void) {    // just ensure some initial variable setup tasks are done
// These configuration arrays need to be set early to choose target CPU so that
// both processor-specific arrays has the proper hash value stored in each of the
// elements. These are calculated at runtime instead of having a set of values
// when compiled, since the same algorithm needs to be run so that the table and
// symbol hashes will match. This way there is flexibility to alter the hashing
// routine without breaking the program.
  if(CF.targetVal==TARGET_1802) {       // all processor-specific
    CF.bigEndian=true;
    CF.hashImmed=false;
    CF.useX_Mode=false;
    if(!starSwapSet) {CF.starSwap=true;}
    CF.branchRelative=false;
    CF.OPC=&OPC1802[0];
    CF.numOp=SIZEOF(OPC1802);         // mnemonics count
    CF.PDEF=&PDEF1802[0];
    CF.numPdef=SIZEOF(PDEF1802);      // predefined count
  }
//
  if(CF.targetVal==TARGET_6800) {     // all processor-specific
    CF.bigEndian=true;
    CF.hashImmed=true;
    CF.useX_Mode=true;
    if(!starSwapSet) {CF.starSwap=false;}
    CF.branchRelative=true;
    CF.OPC=&OPC6800[0];
    CF.numOp=SIZEOF(OPC6800);         // mnemonics count
    CF.PDEF=&PDEF6800[0];
    CF.numPdef=SIZEOF(PDEF6800);      // predefined count
    }
//
  if(CF.targetVal==TARGET_6502) {     // all processor-specific
    CF.bigEndian=false;
    CF.hashImmed=true;
    CF.useX_Mode=true;                // X and Y for this CPU
    if(!starSwapSet) {CF.starSwap=false;}
    CF.branchRelative=true;
    CF.OPC=&OPC6502[0];
    CF.numOp=SIZEOF(OPC6502);         // mnemonics count
    CF.PDEF=&PDEF6502[0];
    CF.numPdef=SIZEOF(PDEF6502);      // predefined count
    }
//
  for(int i=0; i<CF.numOp; i++) {CF.OPC[i].hash=hashit(&CF.OPC[i].name[0]);}      // populates the hash elements of opcode struct array
  for(int i=0; i<CF.numPdef; i++) {CF.PDEF[i].hash=hashit(&CF.PDEF[i].name[0]);}  // populates the hash elements of the predefines array
  for(int i=0; i<SIZEOF(DPC); i++) {DPC[i].hash=hashit(&DPC[i].name[0]);}         // populates the hash elements of directive struct array
  for(int i=0; i<MAX_MACROS; i++) {MDEF[i].textBuff=NULL;}                        // preclear so free() does not use trash values at exit
}
//
int Asm(void) {
  outBytes=PC=Error=0;            // reset these for each pass
  for(pass=0; pass<NUM_PASSES; pass++) {
    numMacros=srcDepth=condLvl=foundEnd=tempLabNum=0;
    for(int i=0; i<MAX_CONDITIONALS; i++) {suppressOutput[i]=false;}
    if(inpfname[0]!='\0') {
      inpHandle=FileOpen(&inpfname[0], "r");
      if(inpHandle==NULL) {
        sprintf_s((char *)&errBuff[0], MAX_LINE_LEN, "File %s cannot be opened.\n", &inpfname[0]);
        errReport();
      }
    }
    if((Error=makePass())!=false) {break;}
    if(pass==0) {PC=outBytes=0;}                            // reset our counters for pass 2, but not at the end of pass 2
    FileClose(inpHandle);
    inpHandle=NULL;

    if(condLvl>0) {
      sprintf_s((char *)&errBuff[0], MAX_LINE_LEN, "Unbalanced conditional directives, too few ENDIFs.\n");
      Error=errReport();
    }
  } // for(pass)
  if(Error==0) {
    if(dirList!=0) {
      dumpSymbols();
      dumpCode();
    }
  }
  if(lstHandle!=NULL) {                                     // close any listing file
    FileClose(lstHandle);
    lstHandle=NULL;
  }
  for(int i=0; i<MAX_MACROS; i++) {                         // free any allocated macro storage blocks
    if(MDEF[i].textBuff!=NULL) {
      free(MDEF[i].textBuff);
      MDEF[i].textBuff=NULL;
    }
  }
  return(Error);
}
//
int errReport(void) {                                       // this reports the error, and sets the Error flag such that looping ends.
  PRINTF("%s line %d: ", &errBuff[0], baseLineNum);
  Error|=1;
  return(Error);
}
//
void lineError(uchar *txt) {
  char fname[MAX_NAME+1]="";
  int line=baseLineNum;                                     // this is the line number outside of includes and macros

  if(pass==0) {return;}                                     // only print errors on second pass
  if(srcDepth!=0) {
    strncpy_s(fname, MAX_NAME+1, (char *)&TxtSrc[srcDepth-1].sname[0], MAX_NAME);
    line=TxtSrc[srcDepth-1].linenum;
    }
  PRINTF("*ERR* %s: line %d %s", fname, line, txt);
}
//
int makePass(void) {
  int err=false;

  baseLineNum=0;                                            // on both passes
  dirList=true;                                             // default for list is on
  while((getLine())==false) {                               // a true error return is likely just EOF, not error
    if(Error!=false) {return(Error);}
    if(((err=processLine())!=false)) {break;}
  } // while(getLine)
  return(err);
}
//
int processLine(void) {
  int err=false, fm=false, sl;

  hadDirField=lineOutBytes=0;
  strcpy_s((char *)&printBuff[0], MAX_LINE_LEN, (char *)&lineBuff[0]);
  // testing for MEND needs to be here, because macro storing skips generateOutput() where each directive is normally processed
  for(int i=0; i<MAX_LINE_LEN; i++) {                     // check if the line is MEND before doing any more collecting.
    if((lineBuff[i]=='\0')||(lineBuff[i]=='\n')) {break;}
    if(((lineBuff[i]=='M')||(lineBuff[i]=='m'))&&((lineBuff[i+1]=='E')||(lineBuff[i+1]=='e'))&&((lineBuff[i+2]=='N')||\
      (lineBuff[i+2]=='n'))&&((lineBuff[i+3]=='D')||lineBuff[i+3]=='d')||\
      ((lineBuff[i]=='E')||(lineBuff[i]=='e'))&&((lineBuff[i+1]=='N')||(lineBuff[i+1]=='n'))&&((lineBuff[i+2]=='D')||\
      (lineBuff[i+2]=='d'))&&((lineBuff[i+3]=='M')||lineBuff[i+3]=='m')) {  // MEND or ENDM
      if(i>0) {if((lineBuff[i-1]!=' ')&&(lineBuff[i-1]!='\t')) {continue;}}   // trap embedded text triggers
        fm=true;
        break;
    }  // case insensitive
  }
  if(fm!=false) {                                         // means the MEND command was detected
    mCollect=false;                                       // toggle collection off
    sl=strlen((char *)&macroInBuff[0]);                   // allocate memory and copy temporary macro buffer to it
    if(pass==0) {                                         // only malloc and copy once
      if(sl!=0) {
        MDEF[numMacros].textBuff=malloc(sl+1);            // add room for null terminator
        if(MDEF[numMacros].textBuff!=NULL) {strcpy_s((char *)MDEF[numMacros].textBuff, sl+1, (char *)&macroInBuff[0]);}
        MDEF[numMacros].slen=sl;                          // don't count the terminator, just the text (including LF as line divider)
      }
    }
  macroInBuff[0]='\0';
  } // if(fm)
  if(mCollect!=false) {   // this is where macro body input lines are collected
    if(pass==0) {         // memorize text lines only on pass 1. If the macro is used, it will be inserted on both passes
      if(((strlen((char *)&macroInBuff[0])+(strlen((char *)&printBuff[0])))>(MAX_BLOCK-1))) {
        lineError((uchar *)"Too many macro characters, or mend/endm not used.\n");
        }
      else {strcat_s((char *)&macroInBuff[0], MAX_BLOCK-1, (char *)&printBuff[0]);}
    }
  }
  else {
  trimLine();
  if(((err=getToks(&lineBuff[0]))!=false)) {return(err);}
  if(((err=processTokens()))!=false) {return(err);}
  if(((err=generateOutput()))!=false) {return(err);}
  }
  if(pass!=0) {printListingLine(&printBuff[0]);}      // prints current line before updating PC and output array
  if(suppressOutput[condLvl]==false) {
    for(int i=0; i<lineOutBytes; i++) {outBuff[outBytes++]=lineOutBuff[i];}
    PC+=lineOutBytes;
  }
  return(err);
}
//
void wList(uchar *strg) {

  if(lstHandle!=NULL) {   // put into file
    FPRINTF(lstHandle, "%s", strg);
    }
  else {PRINTF("%s", strg);}
}
//
void printListingLine(uchar *buff) {
  int thisline=baseLineNum;
  char flch=' ';

  if(dirList==0) {return;}
  if(srcDepth!=0) {thisline=1+TxtSrc[srcDepth-1].linenum; flch='+';}
  if(baseLineNum==1) {
    SPRINTF((char *)&lstBuff[0], MAX_LINE_LEN, "Line |  PC  |    Code    |--- Source --->\n");
    wList(&lstBuff[0]);
    }
  SPRINTF((char *)&lstBuff[0], MAX_LINE_LEN, "%4d%c 0x%04X: ", thisline, flch, PC);
  wList(&lstBuff[0]);
  for(int i=0; i<4; i++) {
    if((i<lineOutBytes)&&(suppressOutput[condLvl]==false)) {     // if suppressOutput==true, just the spaces in the else clause below print
     SPRINTF((char *)&lstBuff[0], MAX_LINE_LEN, "%02X ", lineOutBuff[i]);
     wList(&lstBuff[0]);
    }
    else {
      SPRINTF((char *)&lstBuff[0], MAX_LINE_LEN, "   ");
      wList(&lstBuff[0]);
    }
  }
  SPRINTF((char *)&lstBuff[0], MAX_LINE_LEN, "%s", buff);
  wList(&lstBuff[0]);
}
//
int addSymbol(uchar *buff, int value, int flag) {

  if(symCount>=MAX_SYMBOLS) {PRINT("Too many symbols\n");}
  else {
    strcpy_s(&Symbols[symCount].name[0], MAX_NAME, (char *)buff);
    Symbols[symCount].hash=hashit(buff);
    Symbols[symCount].value=value;
    Symbols[symCount].flags=flag;   // passed value
    ++symCount;
  }
  return(0);
}
//
void dumpSymbols(void) {
  int sw;

  sortSymbols();     // var flag is for expanding sort criteria
  SPRINTF((char *)&spareBuff[0], MAX_LINE_LEN, "   Symbol Table, %d entries.\n", numSorted);
  if(lstHandle!=NULL) {FPRINTF(lstHandle, "%s", &spareBuff[0]); }
  else {PRINTF("%s", &spareBuff[0]); }
  for(int i=0; i<numSorted; i++) {    // use numSorted instead of numSymbols so any filters used will be reflected here
    sw=strlen(&(Sort[i]->name[0]));
    SPRINTF((char *)&spareBuff[0], MAX_LINE_LEN, "%s", &(Sort[i]->name[0]));
    if(lstHandle!=NULL) {FPRINTF(lstHandle, "%s", &spareBuff[0]); }
    else {PRINTF("%s", &spareBuff[0]); }
    for(int k=0; k<MAX_COL_WIDTH-sw; k++) {spareBuff[k]=' '; spareBuff[k+1]='\0';}
    if(lstHandle!=NULL) {FPRINTF(lstHandle, "%s", &spareBuff[0]); }
    else {PRINTF("%s", &spareBuff[0]); }
    SPRINTF((char *)&spareBuff[0], MAX_LINE_LEN, "0x%04X ", Sort[i]->value);
    if(lstHandle!=NULL) {FPRINTF(lstHandle, "%s", &spareBuff[0]); }
    else {PRINTF("%s", &spareBuff[0]); }
    spareBuff[0]=(((Sort[i]->flags)&S_REFERENCED)!=0)?(' '):('U');          // no note or U for unreferenced
    spareBuff[1]=(((Sort[i]->flags)&S_DEFINED)!=0)?('D'):('L');             // definition or label
    spareBuff[1]=(((Sort[i]->flags)&S_MACRO)!=0)?('M'):(spareBuff[1]);      // overwrite either if it's a macro name symbol
    spareBuff[2]='\n';
    spareBuff[3]='\0';
    if(lstHandle!=NULL) {FPRINTF(lstHandle, "%s", &spareBuff[0]); }
    else {PRINTF("%s", &spareBuff[0]); }
  }
}
//
uint hashit(const uchar *buff) {       // using the 32-bit FNV-1 algorithm
  char c;
  uint hash=HASH_OFFSET_32;
  for(; ((c=*buff++)!=0), c+=((c>='A')&&(c<='Z'))?('a'-'A'):(0); hash*=HASH_PRIME_32) {hash^=c;}
  return(hash);
}
//
// this routine first checks hash values, then uses strcmp() to finalize, If the
// named symbol is found, it returns the array index+1, else false if not found.
int findSym(uchar *buff) {
  uint hh=hashit(buff);
  for(int i=0; i<symCount; i++) {
    if(Symbols[i].hash!=hh) {continue;}
    if(strcmp((char *)buff, &Symbols[i].name[0])==0) {  // a hit
      return(i+1);
    }
  }
  return(false);
}
//
// After parsing and matching here is where the code output is created.
// There are two routines, one for processor specific mnemonics.
// A second routine, directiveHandler() manages the non-specific actions.
int generateOutput(void) {
  int res, res2, trt;
  int err=false;
  short opValue;
  uchar optype;
  int opflags;
  short mflags;
  uchar regAdder=0;

  if(fixedOp==0) {return(false);}    // there was no op or directive
  if(fixedType==DIR_TYPE) {return(directiveHandler());}
  opValue=CF.OPC[fixedOp-1].value;
  optype=(CF.OPC[fixedOp-1].flags)&0x00FF;  // masked because upper bits may contain further flags
  opflags=(CF.OPC[fixedOp-1].flags);
  mflags=(CF.OPC[fixedOp-1].mflags);
  switch(optype) {
    case OP_SGL:              // 1-byte, 1-field op
      lineOutBuff[lineOutBytes++]=(uchar)CF.OPC[fixedOp-1].value;            // no reg adders here
      break;
    case OP_WREG:              // 1-byte, 2-field op (reg 0 - 15)
      err=evalExpr(expSym, &res);  // 
      opValue=CF.OPC[fixedOp-1].value+(res&0x000F);
      lineOutBuff[lineOutBytes++]= (uchar)opValue;
      break;
    case OP_OFFSET:            // 2-byte, 2-fields using addr offset (page offset)
      lineOutBuff[lineOutBytes++]= (uchar)CF.OPC[fixedOp-1].value;
      err=evalExpr(expSym, &res);  //
      if(CF.branchRelative!=false) {
        int boyo=res-(PC+2);        // offset is calculated from next instruction location
        if((boyo&0xFF00)!=0) {     // negative overflow
          if(boyo<-128) {lineError((uchar *)"Branch out-of-range, target address too low.\n");}
          }
        else {
          if(boyo>127) {lineError((uchar *)"Branch out-of-range, target address too high.\n");}
        }
        res=boyo;             //
      }
      else {
        int boyd=PC+(res&0x00FF);
        if((PC&0xFF00)!=(boyd&0xFF00)) {lineError((uchar *)"Branch out-of-range, resolves to different page.\n");}
      }
      lineOutBuff[lineOutBytes++]= (uchar)res&0x00FF;
      break;
    case OP_3BITS:             // 1-byte, 2 fields, 2nd field is restricted to 1 - 7 (no zero)
      err=evalExpr(expSym, &res);  // 
      opValue= (uchar)(CF.OPC[fixedOp-1].value+(res&0x07));
      lineOutBuff[lineOutBytes++]= (uchar)opValue;
      break;
    case OP_IMMED:             // 2-byte, 2-field, expression is immediate
      lineOutBuff[lineOutBytes++]= (uchar)CF.OPC[fixedOp-1].value;
      err=evalExpr(expSym, &res);  // 
      lineOutBuff[lineOutBytes++]= (uchar)res&0x00FF;
      break;
    case OP_EXTENDED:          // 3-byte, with 16-bit address word (watch endianess)
      lineOutBuff[lineOutBytes++]= (uchar)CF.OPC[fixedOp-1].value;
      err=evalExpr(expSym, &res);  // 
      if(CF.bigEndian!=false) {
        lineOutBuff[lineOutBytes++]= (uchar)(res>>8)&0x00FF;      // hi byte
        lineOutBuff[lineOutBytes++]= (uchar)res&0x00FF;           // lo byte
      }
      else {
        lineOutBuff[lineOutBytes++]= (uchar)res&0x00FF;           // lo byte
        lineOutBuff[lineOutBytes++]= (uchar)(res>>8)&0x00FF;      // hi byte
      }
      break;
    case OP_WREG_1:            // 1-byte, 2-fields, but reg limited to 1 - 15 (no zero)
      err=evalExpr(expSym, &res);
      opValue=CF.OPC[fixedOp-1].value+(res&0x0F);    // need error reporting if this is zero
      lineOutBuff[lineOutBytes++]= (uchar)opValue;
      break;
     case OP_SGL_AB:
      err=evalExpr(expSym, &res);  // must be A or B or it is an error
      if(AB_RegVal==0) {lineError((uchar *)"Mnemonic is missing required A or B field.\n");}
      if(AB_RegVal==B_REG_FLAG) {  // determine amount to add to opcode when it is B register rather than A register
        regAdder=B_REG_ADD01;
        }
      lineOutBuff[lineOutBytes++]=(uchar)CF.OPC[fixedOp-1].value+regAdder;
      break;
    case OP_ABMODE:
      err=evalExpr(expSym, &res);  // must be A or B or it is an error
      if(AB_RegVal==0) {lineError((uchar *)"Mnemonic is missing required A or B field.\n");}
      if(AB_RegVal==B_REG_FLAG) {  // determine amount to add to opcode when it is B register rather than A register
        regAdder=B_REG_ADD40;
        }
      err=evalExpr(exp2Sym, &res);  // 
      opValue=CF.OPC[fixedOp-1].value;     // immed value, will add fixed amount for other addressing modes
      if(exp3Sym==NULL) {               // cannot be indexed mode because it has no second expression field
        if(immedMode!=false) {
          if((opflags&NO_IMMED)!=0) {lineError((uchar *)"Immediate mode not allowed with this mnemonic.\n");}
          lineOutBuff[lineOutBytes++]=(uchar)opValue+regAdder;
          lineOutBuff[lineOutBytes++]=(uchar)res&0x00FF;            // low byte
          }
        else {                          // either direct or extended 
          if((res&0x00FF00)!=0) {       // extended mode because larger than 8-bits
            lineOutBuff[lineOutBytes++]=(uchar)opValue+regAdder+EXTENDED_ADD;
            lineOutBuff[lineOutBytes++]=(uchar)(res>>8)&0x00FF;    // big-endian, hi byte
            lineOutBuff[lineOutBytes++]=(uchar)res&0x00FF;            // low byte
            }
          else {                      // can only be direct
            lineOutBuff[lineOutBytes++]=(uchar)opValue+regAdder+DIRECT_ADD;
            lineOutBuff[lineOutBytes++]=(uchar)res&0x00FF;            // only low byte for direct mode
            }
          }
        }
      else {      // needs to be indexed or it is an error
        err=evalExpr(exp3Sym, &res2);
        if(indexXMode==false) {lineError((uchar *)"Expected X for indexed mode.\n");}
        lineOutBuff[lineOutBytes++]=(uchar)opValue+regAdder+INDEX_ADD;
        lineOutBuff[lineOutBytes++]=(uchar)res&0x00FF;            // only one byte offset for indexed mode
      }
      break;
    case OP_AMODE:
      err=evalExpr(expSym, &res);  // 
      if((opflags&MAYBE_AB)!=0) {
        if(AB_RegVal!=0) {
          if(AB_RegVal==B_REG_FLAG) {  // determine amount to add to opcode when it is B register rather than A register
            regAdder=B_REG_ADD10;
          }
        opValue=CF.OPC[fixedOp-1].value;                         // base value w/o register B adder
        lineOutBuff[lineOutBytes++]=(uchar)opValue+regAdder;
        break;
        }
      }
      opValue=CF.OPC[fixedOp-1].value;     // immed value, will add fixed amount for other addressing modes
      if(exp2Sym==NULL) {               // cannot be indexed mode because it has no second expression field
        if(immedMode!=false) {
          if((opflags&NO_IMMED)!=0) {lineError((uchar *)"Immediate mode not allowed with this mnemonic.\n");}
          lineOutBuff[lineOutBytes++]=(uchar)opValue;
          if((opflags&IMMED16)!=0) {lineOutBuff[lineOutBytes++]=(uchar)(res>>8)&0x00FF;}   // high byte for 16-bit IMMEDIATE
          lineOutBuff[lineOutBytes++]=(uchar)res&0x00FF;            // low byte
          }
        else {                          // either direct or extended
          if(((res&0x00FF00)!=0)||((opflags&NO_DIRECT)!=0)) {       // extended mode because larger than 8-bits, or forced by flag
            lineOutBuff[lineOutBytes++]=(uchar)opValue+EXTENDED_ADD;
            lineOutBuff[lineOutBytes++]=(uchar)(res>>8)&0x00FF;    // big-endian, hi byte
            lineOutBuff[lineOutBytes++]=(uchar)res&0x00FF;            // low byte
            }
          else {                      // can only be direct
            lineOutBuff[lineOutBytes++]=(uchar)opValue+DIRECT_ADD;
            lineOutBuff[lineOutBytes++]=(uchar)res&0x00FF;            // only low byte for direct mode
            }
          }
        }
      else {      // needs to be indexed or it is an error
        err=evalExpr(exp2Sym, &res2);
        if(indexXMode==false) {lineError((uchar *)"Expected X for indexed mode.\n");}
        lineOutBuff[lineOutBytes++]=(uchar)opValue+INDEX_ADD;
        lineOutBuff[lineOutBytes++]=(uchar)res&0x00FF;            // only one byte offset for indexed mode
      }
      break;
    case OP_MULTA:      // to handle 6502 addressing modes other than inherent and relative
      if((trt=testParenX())!=false) {     // special test and tweak if (nnn,X) addressing (I_INDIR_X)
        if((mflags&F_INDIR_X)==false) {lineError((uchar *)"Indirect,X mode not available for this instruction.\n");}
        }
      err=evalExpr(expSym, &res);   // if it is (,X) the leading parenthesis was skipped over
      if(trt!=false) {              // I_INDIR_X
        lineOutBuff[lineOutBytes++]=opArray6502[opValue&0x00FF][I_INDIR_X];  // array index not used for inherent and branch ops
        lineOutBuff[lineOutBytes++]=(uchar)res&0x00FF;              // only one byte offset for indirect
        break;
      }
      if(AB_RegVal==A_REG_FLAG) { // accumulator mode
        if((mflags&F_ACCUM)==false) {lineError((uchar *)"Accumulator mode not available for this instruction.\n");}
        lineOutBuff[lineOutBytes++]=opArray6502[opValue&0x00FF][I_ACCUM];  // array index not used for inherent and branch ops
        break;
      }
      if(immedMode!=0) {      // I_IMMED
        if((mflags&F_IMMED)==false) {lineError((uchar *)"Immediate mode not available for this instruction.\n");}
          lineOutBuff[lineOutBytes++]=opArray6502[opValue&0x00FF][I_IMMED];  // array index not used for inherent and branch ops
          lineOutBuff[lineOutBytes++]=(uchar)res&0x00FF;               // one byte immediate
          break;
        }
      if(exp2Sym==NULL) {   // this excludes the zero page, X and Y absolute and Y indirect modes from this block
        if((res>0x00FF)||((res<=0x00FF)&&((mflags&F_ZEROPG)==false))) {    // >255 means it would be absolute,
          //not zero page unless zero page is not allowed, then it is assembled as absolute
          if((mflags&F_ABS)==false) {lineError((uchar *)"Absolute mode not available for this instruction.\n");}
          lineOutBuff[lineOutBytes++]=opArray6502[opValue&0x00FF][I_ABS];  // array index not used for inherent and branch ops
          lineOutBuff[lineOutBytes++]=(uchar)res&0x00FF;               // little endian low byte
          lineOutBuff[lineOutBytes++]=(uchar)(res>>8)&0x00FF;          // high byte
        }
        else {              // then it has to be zero page addressing
          if((mflags&F_ZEROPG)==false) {lineError((uchar *)"Zero page mode not available for this instruction.\n");}
          lineOutBuff[lineOutBytes++]=opArray6502[opValue&0x00FF][I_ZEROPG];  // array index not used for inherent and branch ops
          lineOutBuff[lineOutBytes++]=(uchar)res&0x00FF;                      // low byte
        }
        break;
      }   // exp2Sym must not be null if the code got here
      // sort out Zero page X, Absolute X, Absolute Y and Indirect Y
      err=evalExpr(exp2Sym, &res2);   // this should have X or Y flags set (A was already checked), or it is an error
      if(indexXMode!=false) {   // either Zero page X or Absolute X, Indirect X was already eliminated
        if(res>0x00FF) {          // absolute mode needed. value comes from first evalExpr() call
          if((mflags&F_ABS_X)==false) {lineError((uchar *)"Absolute X mode not available for this instruction.\n");}
          lineOutBuff[lineOutBytes++]=opArray6502[opValue&0x00FF][I_ABS_X];  // array index not used for inherent and branch ops
          lineOutBuff[lineOutBytes++]=(uchar)res&0x00FF;               // little endian low byte
          lineOutBuff[lineOutBytes++]=(uchar)(res>>8)&0x00FF;          // high byte
        }
        else {
          if((mflags&F_ZEROPG_X)==false) {lineError((uchar *)"Zero page X mode not available for this instruction.\n");}
          lineOutBuff[lineOutBytes++]=opArray6502[opValue&0x00FF][I_ZEROPG_X];  // array index not used for inherent and branch ops
          lineOutBuff[lineOutBytes++]=(uchar)res&0x00FF;               // little endian low byte
        }
      }
      else {   // if it isn't Y mode, there is an error
        if(indexYMode==false) {lineError((uchar *)"No recognizable addressing mode detected.\n");}
        else {      // Y mode
          if(parenMode) {   // expression had an opening parenthesis in it
            if((mflags&F_INDIR_Y)==false) {lineError((uchar *)"Indirect Y mode not available for this instruction.\n");}
            lineOutBuff[lineOutBytes++]=opArray6502[opValue&0x00FF][I_INDIR_Y];  // array index not used for inherent and branch ops
            lineOutBuff[lineOutBytes++]=(uchar)res&0x00FF;               // little endian low byte
          }
          else {    // has to be Zero page Y or Absolute Y
            if(res>0x00FF) {        // this needs to use the first expression value size
              if((mflags&F_ABS_Y)==false) {lineError((uchar *)"Absolute Y mode not available for this instruction.\n");}
              lineOutBuff[lineOutBytes++]=opArray6502[opValue&0x00FF][I_ABS_Y];  // array index not used for inherent and branch ops
              lineOutBuff[lineOutBytes++]=(uchar)res&0x00FF;               // little endian low byte
              lineOutBuff[lineOutBytes++]=(uchar)(res>>8)&0x00FF;          // high byte
            }
            else {      // may be ZERO PAGE Y
              if((mflags&F_ZEROPG_Y)==false) {lineError((uchar *)"Zero Page Y mode not available for this instruction.\n");}
              lineOutBuff[lineOutBytes++]=opArray6502[opValue&0x00FF][I_ZEROPG_Y];  // array index not used for inherent and branch ops
              lineOutBuff[lineOutBytes++]=(uchar)res&0x00FF;               // little endian low byte
            }
          }
        } // else
      } // else
      break;
    case OP_MULTJ:      // to handle 6502 addressing modes for JMP
      err=evalExpr(expSym, &res);   // only two are ABS $xxxx and Indirect ($nnnn). There is a flag for the parens
      if(parenMode) {   // expression had an opening parenthesis in it
        if((mflags&F_INDIR)==false) {lineError((uchar *)"Indirect mode not available for this instruction.\n");}
        lineOutBuff[lineOutBytes++]=opArray6502[opValue&0x00FF][I_INDIR];  // array index not used for inherent and branch ops
        lineOutBuff[lineOutBytes++]=(uchar)res&0x00FF;               // little endian low byte
        lineOutBuff[lineOutBytes++]=(uchar)(res>>8)&0x00FF;          // little endian high byte
      }
      else {
        if((mflags&F_ABS)==false) {lineError((uchar *)"Absolute mode not available for this instruction.\n");}
        lineOutBuff[lineOutBytes++]=opArray6502[opValue&0x00FF][I_ABS];  // array index not used for inherent and branch ops
        lineOutBuff[lineOutBytes++]=(uchar)res&0x00FF;               // little endian low byte
        lineOutBuff[lineOutBytes++]=(uchar)(res>>8)&0x00FF;          // little endian high byte
      }
      break;
    // additional ops go here
    default:
      break;
    } // switch(optype)
  return(err);
}
//
// this is here to keep ($xx,X) from erroring due to unbalanced parentheses,
// since it will be split at the comma by the token parser.
// the X) is matched literally
int testParenX() {
  if((expSym!=NULL)&&(exp2Sym!=NULL)) {
    if((*expSym=='(')&&((*exp2Sym=='x')||(*exp2Sym=='X'))&&(*(exp2Sym+1)==')')) {
      ++expSym;       // move past leading parenthesis to allow evalExp to work on first argument
      return(true);   // it's weally twue!
      }
    } // null check
  return(false);    // false if not ( ,X) mode
  }
// Non-processor specific functions are handled here
int directiveHandler() {
  int res, rt, rn;
  int optype, opflags;
  int err=false;

  optype=(DPC[fixedOp-1].flags)&0x00FF;  // masked because upper bits may contain further flags
  opflags=(DPC[fixedOp-1].flags);
  switch(DPC[fixedOp-1].value) {
    case DIR_EQU:
      if(expSym==NULL) {
        lineError((uchar *)"Directive EQU lacks required value expression.\n");
        break;
        }                                   // error here
      err=evalExpr(expSym, &res);               // 
      if(labelSym==NULL) {
        lineError((uchar *)"Directive EQU lacks required label.\n");
        break;
      }                                     // error here
      if((rt=findSym(labelSym))==0)   {break;}    // error here, too
      Symbols[rt-1].value=res;                    // set it to what was given
      Symbols[rt-1].flags|=S_DEFINED;
      break;
    case DIR_ORG:
      if(expSym==NULL) {
        lineError((uchar *)"Directive ORG lacks required value expression.\n");
        break;
        }     // error here
      err=evalExpr(expSym, &res);               //
      Origin=res;
      PC=Origin;
      break;
    case DIR_DB:
      for(int i=0; i<tokenCount; i++) {
        if(tokens[i]==labelSym) {continue;}
        if(tokens[i]==oprSym) {continue;}
        err=evalExpr(tokens[i], &res);         //
        lineOutBuff[lineOutBytes++]= (uchar)(res&0x00FF);
      }
      break;
    case DIR_HEX:
      if(expSym==NULL) {
        lineError((uchar *)"Directive HEX lacks required value expression.\n");
        break;
        }     // error here
      copyExpStr(expSym, &hexfname[0]);
      break;
    case DIR_BIN:
      if(expSym==NULL) {
        lineError((uchar *)"Directive BIN lacks required value expression.\n");
        break;
      }     // error here
      copyExpStr(expSym, &binfname[0]);
      break;
    case DIR_INC:
      if(expSym==NULL) {
        lineError((uchar *)"Directive INCLUDE lacks required value expression.\n");
        break;
      }     // error here
      copyExpStr(expSym, &incfname[0]);     // 
      if(++srcDepth>MAX_SRC_NESTS) {
        sprintf_s((char *)&errBuff[0], MAX_LINE_LEN, "Too many nested INCLUDE or MACRO directives (max=%d).\n", MAX_SRC_NESTS);
        err=errReport();
        break;
      }
      TxtSrc[srcDepth-1].type=SRC_INCLUDE;
      strcpy_s((char *)&TxtSrc[srcDepth-1].sname[0], MAX_FILE_NAME, (char *)&incfname[0]);
      TxtSrc[srcDepth-1].linenum=0;
      TxtSrc[srcDepth-1].include=FileOpen(&incfname[0], "r");    // incremented above. decremented in getLine()
      if(TxtSrc[srcDepth-1].include==NULL) {
        sprintf_s((char *)&errBuff[0], MAX_LINE_LEN, "Failed to open INCLUDE file.\n");
        err=errReport();
        break;
      }
      break;
    case DIR_ALIGN:
      if(expSym==NULL) {
        lineError((uchar *)"Directive ALIGN lacks required value expression.\n");
        break;
      }
      err=evalExpr(expSym, &res);
      if(res!=0) {
       rn=(res-(PC%res));
       if(rn!=res) {
         for(int i=0; i<rn; i++) {lineOutBuff[lineOutBytes++]=fillByte;}  // pad with filler, PC updates in generateOutput()
        }
      }
      break;
    case DIR_ASCII:
    case DIR_ASCIZ:
      if(expSym==NULL) {
        lineError((uchar *)"Directive lacks required string expression.\n");
        break;
      }
      copyExpStr(expSym, &spareBuff[0]);
      rn=strlen((char *)&spareBuff[0]);
      for(int i=0; i<rn; i++) {lineOutBuff[lineOutBytes++]=spareBuff[i];}
      if(DPC[fixedOp-1].value==DIR_ASCIZ) {lineOutBuff[lineOutBytes++]='\0';}
      break;
    case DIR_LIST:
      dirList=true;
      break;
    case DIR_NOLIST:
      dirList=false;
      break;
    case DIR_FILLER:
      if(expSym==NULL) {
        lineError((uchar *)"Directive FILLER lacks required value expression.\n");
        break;
      }
      err=evalExpr(expSym, &res);
      fillByte=(res&0x00FF);
      break;
    case DIR_MACRO:
      if(mCollect!=false) {
        lineError((uchar *)"MACRO definitions cannot be nested.\n");
      }
      else {mCollect=true;}
      macroInBuff[0]='\0';
      if(labelSym==NULL) {
        lineError((uchar *)"Directive MACRO lacks required name label.\n");
        break;
      }
      if((rt=findSym(labelSym))==0) {
        if(++numMacros>MAX_MACROS) {
          sprintf_s((char *)&errBuff[0], MAX_LINE_LEN, "Too many macros defined (max=%d).\n", MAX_MACROS);
          return(errReport());
        }
        addSymbol(tokens[0], numMacros, (S_ISLABEL|S_MACRO));
        MDEF[numMacros].idNum=numMacros;
      }
      else {
        if(++numMacros>MAX_MACROS) {
          sprintf_s((char *)&errBuff[0], MAX_LINE_LEN, "Too many macros defined (max=%d).\n", MAX_MACROS);
          return(errReport());
        }
        Symbols[rt-1].value=numMacros;
        MDEF[numMacros].idNum=numMacros;
        Symbols[rt-1].flags|=S_MACRO;
      }
      break;
    case DIR_MEND:  // all this is really done in getLine() routine, case here for completeness
      break;
    case DIR_ISIF:
      if(expSym==NULL) {
        lineError((uchar *)"Conditional directive IF lacks required value expression.\n");
        break;
      }
      err=evalExpr(expSym, &res);
      if(++condLvl>MAX_CONDITIONALS) {
        sprintf_s((char *)&errBuff[0], MAX_LINE_LEN, "Too many nested conditional directives (max=%d).\n", MAX_CONDITIONALS);
        err=errReport();
      }
      suppressOutput[condLvl]=(res==0)?(true):(false);    // this is negative logic, a 0 result means suppress, which requires true in var
      break;
    case DIR_ISNIF:
      if(expSym==NULL) {
        lineError((uchar *)"Conditional directive IFN lacks required value expression.\n");
        break;
      }
      err=evalExpr(expSym, &res);
      if(++condLvl>MAX_CONDITIONALS) {
        sprintf_s((char *)&errBuff[0], MAX_LINE_LEN, "Too many nested conditional directives (max=%d).\n", MAX_CONDITIONALS);
        err=errReport();
      }
      suppressOutput[condLvl]=(res!=0)?(true):(false);    // this is reverse logic, a 1 result means suppress, which requires true in var
      break;
    case DIR_ELSE:
      suppressOutput[condLvl]=(suppressOutput[condLvl]==false)?(true):(false);  // flips the suppression status
      break;
    case DIR_ENDIF:
      suppressOutput[condLvl]=false;                       // turn suppression off, no matter what the prior state was
      if(--condLvl<0) {
        condLvl=0;
        lineError((uchar *)"More ENDIF directives than IF or IFN used.\n");
      }
      break;
    case DIR_CSRC:
      if(expSym==NULL) {
        lineError((uchar *)"Directive CSRC lacks required value expression.\n");
        break;
      }     // error here
      copyExpStr(expSym, &csrcfname[0]);
      break;
    case DIR_SREC:
      if(expSym==NULL) {
        lineError((uchar *)"Directive SREC lacks required value expression.\n");
        break;
      }     // error here
      copyExpStr(expSym, &srecfname[0]);
      break;
    case DIR_REDEF:
      if(expSym==NULL) {
        lineError((uchar *)"Directive REDEF lacks required value expression.\n");
        break;
        }                                   // error here
      err=evalExpr(expSym, &res);               // 
      if(labelSym==NULL) {
        lineError((uchar *)"Directive REDEF lacks required label.\n");
        break;
      }                                     // error here
      if((rt=findSym(labelSym))==0)   {break;}    // error here, too
      if((Symbols[rt-1].flags&=S_DEFINED)==0) {
        lineError((uchar *)"Directive REDEF cannot be used on location target label.\n");
        break;
        }
      Symbols[rt-1].value=res;                    // set it to what was given
      break;
    case DIR_DS:
      if(expSym==NULL) {
        lineError((uchar *)"Directive DS lacks required value expression.\n");
        break;
        }                                   // error here
      err=evalExpr(expSym, &res);               // 
      if(labelSym==NULL) {
        lineError((uchar *)"Directive DS lacks required label.\n");
        break;
      }                                     // error here
      if((rt=findSym(labelSym))==0)   {break;}    // error here, too
      Symbols[rt-1].value=PC;                     // set it to what was given
      PC+= res;                                   // PC bump but no code generation
      break;
    case DIR_DW:
      for(int i=0; i<tokenCount; i++) {           // double bytes, no alignment checking
        if(tokens[i]==labelSym) {continue;}
        if(tokens[i]==oprSym) {continue;}
        err=evalExpr(tokens[i], &res);            //
        if(CF.bigEndian!=false) {
          lineOutBuff[lineOutBytes++]= (uchar)((res>>8)&0x00FF);  // high byte/low byte
          lineOutBuff[lineOutBytes++]= (uchar)(res&0x00FF);
          }
        else {
          lineOutBuff[lineOutBytes++]= (uchar)(res&0x00FF);       // low byte/high byte
          lineOutBuff[lineOutBytes++]= (uchar)((res>>8)&0x00FF);
        }
      }
      break;
    case DIR_END:
      foundEnd=true;
      break;
  // additional directives go here
    default:
      break;
  } // switch(value)
  return(err);
}
//
void copyExpStr(uchar *src, uchar *dest)  {
  int slen=strlen((char *)src);
  if(slen!=0) {
    if((*(src)=='\"')&&(*(src+slen-1)=='\"')) {    // looking for a quoted string
      *(src+slen-1)='\0';
      strcpy_s((char *)dest, MAX_FILE_NAME, (char *)(src+1));
    }
  }
}
//
void dumpCode(void) {   // just to look at output, output was already saved, if enabled
  if(hexfname[0]!='\0') {iHexToFile(&outBuff[0], outBytes, Origin);}
  if(binfname[0]!='\0') {binToFile(&outBuff[0], outBytes);}
  if(csrcfname[0]!='\0') {csrcFile(&outBuff[0], outBytes);}
  if(srecfname[0]!='\0') {srecFile(&outBuff[0], outBytes, Origin);}
  if(lstHandle!=NULL) {
    for(int i=0; i<outBytes; i++) {FPRINTF(lstHandle, "%02X ", outBuff[i]);}
    FPRINTF(lstHandle, "\n");
  }
  else {
    for(int i=0; i<outBytes; i++) {PRINTF("%02X ", outBuff[i]);}
    PRINTF("\n");
  }
}
//
int processTokens(void) {
  int slen, ndx, rtv;
  int err=false;
  int hadlabel=false;

  labelSym=oprSym=expSym=exp2Sym=exp3Sym=NULL;
  fixedOp=0;
  if(tokenCount==0) {return(false);}      // blank or comment only line
  // look to see if line has a label, if so add it to symbols
  slen=(strlen((char *)tokens[0]));   // determine if colon present at end and strip it
  if(slen!=0) {
    if((((tokens[0])[slen-1])==':')||((lineBuff[0]!=' ')&&(lineBuff[0]!='\t'))) {   // at line start or followed by colon
      if(tokens[0][slen-1]==':') {tokens[0][slen-1]='\0';}                          // eliminate the colon if present
      labelSym=tokens[0];
      hadlabel=true;
      if((ndx=findSym(tokens[0]))!=0) {                                             // symbol found: return value is index+1
        if(((Symbols[ndx-1].flags&(S_DEFINED|S_FWDREF))==0)&&(pass==0)) {           // equ symbols may be redefined, but not location target labels
          sprintf_s((char *)&errBuff[0], MAX_LINE_LEN, "Duplicate definition of target label %s.\n", tokens[0]);
          return(errReport());
        }
        if(pass==0) {Symbols[ndx-1].value=PC;}       // label definition, may be overridden by EQU or for a MACRO
          Symbols[ndx-1].flags|=S_ISLABEL;
//        Symbols[ndx-1].flags&=(~(S_FWDREF));            // remove any forward referenced flag
      }
      else {addSymbol(tokens[0], PC, (S_ISLABEL|S_FWDREF));}       // "here" for a label
    }
  }
  if(hadlabel!=true) {          // sorting through fields, based on whether there was a label or not
    oprSym=tokens[0];
    expSym=tokens[1];
    exp2Sym=tokens[2];      // could be null like expSym
    exp3Sym=tokens[3];
    }
  else {
    oprSym=tokens[1];
    expSym=tokens[2];
    exp2Sym=tokens[3];
    exp3Sym=tokens[4];
    }
  if(oprSym!=NULL) {
    if((rtv=findSym(oprSym))!=0) {return(macroCall(rtv, hadlabel));}  // check for macro here
    fixedType=0;
    fixedOp=matchFixed(oprSym, &fixedType);
    if(fixedOp==0)  {
      sprintf_s((char *)&errBuff[0], MAX_LINE_LEN, "Unrecognized mnemonic/directive/macro \"%s\".\n", oprSym);
      lineError(&errBuff[0]);
    }
  }
  return(err);
}
//
// this routine is to add a macro source to be parsed by getLine()
// it bypasses generateOutput(), since the macro call line generates no code,
// but instead saves the parms and configures the saved text to be the next input.
// if hadlabel is true, parms start at tokens[2], if false, tokens[1]
int macroCall(int sndx, int hadlabel) {   // the parameter is the index+1 returned from findSym.
  int ft, err=0, mn, hm=false, bz=0;

//  PRINTF("macroCall() pass=%d hadlabel=%d PC=0x%04X\n", pass, hadlabel, PC);
  if((Symbols[sndx-1].flags&S_MACRO)==0) {    // error to have non-macro symbol in operand field
    sprintf_s((char *)&errBuff[0], MAX_LINE_LEN, "Non-macro symbol used in mnemonic/directive field.\n");
    return(errReport());
  }
  // create and populate macro source here
  if(++srcDepth>MAX_SRC_NESTS) {
    sprintf_s((char *)&errBuff[0], MAX_LINE_LEN, "Too many nested INCLUDE or MACRO directives (max=%d).\n", MAX_SRC_NESTS);
    return(errReport());
  }
  TxtSrc[srcDepth-1].type=SRC_MACRO;
  strcpy_s((char *)&(TxtSrc[srcDepth-1].sname[0]), MAX_FILE_NAME, &(Symbols[sndx-1].name[0]));    // copy the string (macro or include)
  TxtSrc[srcDepth-1].linenum=0;
  for(int i=0; i<NUM_MACRO_PARMS; i++) {TxtSrc[srcDepth-1].parms[i][0]='\0';}
  ft=(hadlabel!=false)?(2):(1);
  for(int i=ft; i<(NUM_MACRO_PARMS+ft); i++) {
    if(tokens[i]!=NULL) {strcpy_s((char *)&TxtSrc[srcDepth-1].parms[bz++][0], MAX_FILE_NAME, (char *)tokens[i]);}
    else {break;}                                     // first null means there should be no more after
  }
  Symbols[sndx-1].flags|=S_REFERENCED;
  mn=Symbols[sndx-1].value;
  for(int i=0; i<MAX_MACROS; i++) {
    if(MDEF[i].idNum==mn) {                           // this is a value assigned sequentially when macro symbol was defined and links Symbol[] and MDEF[] structs
      TxtSrc[srcDepth-1].textBuff=MDEF[i].textBuff;   // mdef structure exists to hold malloc() memory to be freed at program exit, copied for ease of use
      TxtSrc[srcDepth-1].readNdx=0;                   // this will index text lines until null termination marks macro exhaustion so it is pulled from input stack
      TxtSrc[srcDepth-1].slen=MDEF[i].slen;           // this length was calculated when the MDEF node was created, no need to count it every invocation
      hm=true;
      break;
      }
  }
  if(hm!=true) {
    sprintf_s((char *)&errBuff[0], MAX_LINE_LEN, "Undefined MACRO link error (ID=%d).\n", mn);
    return(errReport());
    }
  return(err);
}
//
// After a line is tokenized, this function tries to match the operator field (middle one).
// There are two tables that guide it, one has processor-specific items, and a second holds
// the key data for generic and house-keeping functions, such as included files and macro capture.
int matchFixed(uchar *buff, int *type) {    // returns index+1, 0 means no matches
  int cret;

  if((*buff)=='.') {buff++;}    // skips any initial dot character, so only one hash table entry is needed
  uint hh=hashit(buff);
  for(int i=0; i<CF.numOp; i++) {        // scan mnemonic table
    if(CF.OPC[i].hash!=hh) {continue;} // go back to top
    cret=strcaselesscmp(buff, &CF.OPC[i].name[0]);
    if(cret==0) {
      *type=OP_TYPE;          // a mnemonic operator, separate from directives
      return(i+1);    // table index+1
    }
  }
  for(int i=0; i<SIZEOF(DPC); i++) {     // scan directive table
    if(DPC[i].hash!=hh) {continue;} // go back to top
    cret=strcaselesscmp(buff, &DPC[i].name[0]);
    if(cret==0) {
      *type=DIR_TYPE;   // set the directive type to distinguish from menmonic index
      return(i+1);    // table index+1
    }
  }
  return(0);   // a zero function return means no match
}
//
int strcaselesscmp(const uchar *a, const uchar *b) {    // case insensitive strcmp(), adapted from K&R manual example
  for(;(((*a>='A')&&(*a<='Z'))?((*a)+('a'-'A')):(*a))==(((*b>='A')&&(*b<='Z'))?((*b)+('a'-'A')):(*b)); a++, b++) {
    if(*a=='\0') {return(0);}   // if *b is zero and *a is not, rountine exits anyway before here due to the equality test failing
    }
  return(*a-*b);
}
//
int getLine(void) { // extracts a single line from a multi-line buffer or from a file
  int ret, clen, ndx=0;
  char c, ch;

  immedMode=parenMode=false;     // reset on each line. If evalExpr detects # it will set this to true when CF.hashImmed is true
  indexXMode=indexYMode=false;    // reset on each line. If evalExpr matches X or Y as a symbol when CF.useX_Mode is true.
  hadAtSign=false;              // reset on each line. Used if @ in expression to indicate indirect mode.

  AB_RegVal=0;
  if(foundEnd!=false) {return(1);}              // that's all, folks.
  if(srcDepth!=0) {       // this nests both include and macro file sources
    if(TxtSrc[srcDepth-1].type==SRC_INCLUDE) {
      ret=FileGetS(&lineBuff[0], MAX_LINE_LEN-1, TxtSrc[srcDepth-1].include);
      ++TxtSrc[srcDepth-1].linenum;
      if(ret==false) {
        FileClose(TxtSrc[srcDepth-1].include);
        TxtSrc[srcDepth-1].include=NULL;
        --srcDepth;
        return(getLine());       // recursive call here
      }    // assume it is EOF (but could be error)
    }
    else {  // macro source reads go here
      if(TxtSrc[srcDepth-1].type!=SRC_MACRO) {
        sprintf_s((char *)&errBuff[0], MAX_LINE_LEN, "Unspecified text source value 0x%04X.\n", TxtSrc[srcDepth-1].type);
        return(errReport());
      }
      if(TxtSrc[srcDepth-1].readNdx>=TxtSrc[srcDepth-1].slen) { // dismantle struct and return recursive call
        --srcDepth;          // lower stack top
        return(getLine());   // get requested call from next lower stacked source, or original file if zero (no TxtSrc structs stacked)
      }
      clen=TxtSrc[srcDepth-1].slen-TxtSrc[srcDepth-1].readNdx;
      for(int i=0; i<clen; i++) {
        c=TxtSrc[srcDepth-1].textBuff[TxtSrc[srcDepth-1].readNdx++];
        ch=TxtSrc[srcDepth-1].textBuff[TxtSrc[srcDepth-1].readNdx];   // readNdx was incremented in line above
        if(c=='\0') {
          lineBuff[ndx]=c;    // ensure null termination
          break;
        }
        if((c=='\\')&&((ch>='1')&&(ch<='9'))) {   // text expansion from calling parameters is done here
          strcat_s((char *)&lineBuff[ndx], MAX_LINE_LEN, (char *)&TxtSrc[srcDepth-1].parms[ch-'1'][0]);
          ndx+=strlen((char *)&TxtSrc[srcDepth-1].parms[ch-'1'][0]);
          TxtSrc[srcDepth-1].readNdx++;     // just skip past the parm number after the backslash
        }
        else {
          lineBuff[ndx++]=c;  // go ahead and copy, then add null terminator
          lineBuff[ndx]='\0';   // add null terminator so a no LF line won't break here
        }
        if(c=='\n') {break;}  // already copied the LF and put a terminator after it, so routine is finished for this line
      }
    ++TxtSrc[srcDepth-1].linenum;
    }
  }
  else {
    ++baseLineNum;
    ret=FileGetS(&lineBuff[0], MAX_LINE_LEN-1, inpHandle);
    if(ret==false) {return(true);}    // assume it is EOF (but could be error)
  }
  return(0);
}
//
void trimLine(void) {  // just trim out any comment part of the line - looks for ; .. or // (asm OR c-style)
  char c;
  int quoted=0;
  int slen=strlen((char *)&lineBuff[0]);

  for(int i=0; i<slen; i++) {
    c=lineBuff[i];
    if((c=='\'')||(c=='\"')) {(quoted=(quoted!=0)?(0):(1));} // flip state
    if(quoted==0) {
      if((c==';')||((c=='/')&&(lineBuff[i+1]=='/'))||((c=='.')&&(lineBuff[i+1]=='.'))) { // trim here and quit
      lineBuff[i]='\0';
      break;
      } // else just continue
    }
  }
  return;
}
//
int getToks(uchar *buffIn) {        // this was modified to use findTok() instead of srttok() to get all of quoted strings
  uchar *tok=NULL;
  int err=false;

  tokenCount=0;
  for(int i=0; i<MAX_TOKENS; i++) {tokens[i]=NULL;}   // so there are no stale pointers in shorter lines
                                                      // strtok() replaced by findTok() function
  tok=findTok(buffIn, true);                        // set flag true on first call
  if(tok!=NULL) {tokens[tokenCount++]=tok;}
  else {return(false);}                               // empty line (maybe comment only)  
  while(tok!=NULL) {
    tok=findTok(NULL, false);                       // set first call flag to false for remaining calls
    if(tok!=NULL) {tokens[tokenCount++]=tok;}
    if(tokenCount>=MAX_TOKENS) {err=true; break;}       // enforce array limit
  }
  return(err);
}
//
uchar *findTok(uchar *buff, int begin) { // replacement for strtok() to recognize quoted string fields as well as whitespace ones
  static uchar *fnPtr;         // whitespace are space, tab, CR and LF (LF is a line end flag, though)
  uchar *ptr;
  uchar c, qtype;
  int quoted=false;

  if(begin!=false) {  // initialize routine, fnPtr is find now
    ptr=fnPtr=buff;
    fntPtr=NULL;
    }
  else {
    if(fntPtr==NULL) {return(NULL);}        // routine was apparently used without a prior begin=true call or found eol last time
    else {fnPtr=ptr=fntPtr; fntPtr=NULL;}   // transfer previous start location to current start location
    }                                       // fntPtr is the find next time location
  while((c=*ptr)!=0) {                      // move past whitespace to quote or other
    if((c=='\"')||(c=='\'')                     ) {quoted=true; break;}
    if((c==' ')||(c=='\t')||(c=='\r')||(c==',')) {++ptr;} // whitespace/delimiters include a comma
    else {break;}                           // non-whitespace character
  } // while(c)
  if((c=='\0')||(c=='\n')) {return(NULL);}  // all white space or ran off end of string
  if(quoted!=false) { // gather up all between quotes
    qtype=c;        // single or double quote
    fnPtr=ptr;       // start pointer (initial quote)
    ++ptr;          // set to start after initial quote
    while((c=*ptr)!='\0') {
      if(c=='\\') {     // check for escaped quotes (allowed)
        if((*(ptr+1)=='\"')||(*(ptr+1)=='\'')) {
          ptr+=2;       // skip over it (these are not the bots you're looking for)
          continue;
          }   //
      }
      if(c==qtype) {
        *(++ptr)='\0';   // right after the quote
        fntPtr=++ptr;   // right after the null that was inserted
        return(fnPtr);  // finished with quoted string
      }
      if((c=='\n')||(c=='\0')) {return(NULL);}  // no ending quote, ran off line end
      ++ptr;              // walk past other characters
    } // while
  } // if
  else {   // gather non-whitespace characters until a whitespace detected
    fnPtr=ptr;    // this is where non-whitespace starts
    while((c=*ptr)!='\0') {
      if((c==' ')||(c=='\t')||(c=='\r')||(c=='\n')||(c==',')) { break; }    // found a whitespace/delimiter char
      ++ptr;
    }
    if(c=='\0') {     // if a line-ending null, flag for no future returns until begin=true call
      fntPtr=NULL;
      return(fnPtr);
    }
    *ptr++='\0';
    fntPtr=ptr;
    return(fnPtr);
  } // else
  return(NULL);   // huh? a failure if code got here
}
int matchPredef(uchar* buff) {    // returns index+1, 0 means no matches
	int cret;
	uint hh = hashit(buff);

	for (int i=0; i<CF.numPdef; i++) {
		if (CF.PDEF[i].hash!=hh) {continue;} // go back to top
		cret=strcaselesscmp(buff, &CF.PDEF[i].name[0]);
		if(cret==0) {return(i+1);}    // index+1
	}
	return(0);                            // a zero function return means no match
}
//
uchar atoh(uchar c) {
	if((c>='0')&&(c<='9')) {return(c&0x0F);}       // ascii hex conversions
	if((c>='A')&&(c<='F')) {return(10+(c-'A'));}
	if((c>='a')&&(c<='f')) {return(10+(c-'a'));}  // shouldn't normally lower case, but may as well make it legit
	return(0); // a bust, really but something has to go back to the caller
}
//
// intel hex file line starts with ':' (not used in checksum)
// next comes the byte_count (usually 16) as two hex digits
// then a 4 character (16-bit) address field.... Hi/Lo (big endian, or network order)
// then a two digit (1 byte) record type. 00=data, 01=eof 02 to 05 useless for this
// now comes byte_count bytes as two hex digits per byte.
// then finally a checksum (and newline).
// checksum is the sum of all the bytes, subtracted from zero. 2 hex char, 1 byte.
//
int binToFile(const uchar *src, int sz) {
	FILE *file;

  if(lstHandle!=NULL) {FPRINTF(lstHandle, "Creating %s\n", &binfname[0]);}
  else {PRINTF("Creating %s\n", &binfname[0]);}
	file = FileOpen(&binfname[0], FILE_WRITE);
  if(file!=NULL) {
  	FilePutS(src, sz, file);
	  FileClose(file);
    }
  else {PRINTF("Could not create file %s.\n", &binfname[0]);}
	return(0);
}
//
int iHexToFile(const uchar* src, int sz, int baseAddr) {
	FILE *file;

  if(lstHandle!=NULL) {FPRINTF(lstHandle, "Creating %s\n", &hexfname[0]);}
  else {PRINTF("Creating %s\n", &hexfname[0]);}
	file = FileOpen(&hexfname[0], FILE_WRITE);
  if(file!=NULL) {
  	iHexWriteSD(src, sz, file, baseAddr);
	  FileClose(file);
    }
  else {PRINTF("Could not create file %s.\n", &binfname[0]);}
  return(0);
}
//
void ctohd(uchar *p, uchar c) {
  uchar f, g;
  f=((c>>4)&0x000F);
  g=(c&0x000F);
  *p++=(f>0x09)?('A'+(f-10)):('0'+f);
  *p=(g>0x09)?('A'+(g-10)):('0'+g);
}
//
int iHexWriteSD(const uchar *src, int sz, FILE *file, const int baseAddr) {
	uchar intLineBuff[MAX_LINE_LEN]="";
	uchar tmpLineBuff[MAX_LINE_LEN]="";
	int Addr, recType, chksum;
	int fullBlk, partBlk, ndx;

	Addr = baseAddr;
	fullBlk = sz / IHEX_BYTES;      // number of full lines
	partBlk = sz % IHEX_BYTES;      // size of partial count line
	recType = 0;                  // record type

	for(int i=0; i<fullBlk; i++) {    // this loop creates all the full IHEX_BYTES (16-byte) lines
		chksum=0;
		for(int j=0; j<IHEX_BYTES; j++) {
			intLineBuff[j]=*(src++);
			chksum+=intLineBuff[j];
		}   // get all our bytes

    ndx=0;
    tmpLineBuff[ndx++]=':';
    ctohd(&tmpLineBuff[ndx], IHEX_BYTES);
    ndx+=2;
    ctohd(&tmpLineBuff[ndx], ((Addr >> 8)&0x00FF));
    ndx+=2;
    ctohd(&tmpLineBuff[ndx], (Addr & 0x00FF));
    ndx+=2;
    ctohd(&tmpLineBuff[ndx], recType&0x00FF);
    ndx+=2;
		chksum+=(IHEX_BYTES+(Addr>>8)+(Addr&0x00FF)+recType);
		chksum=((0-chksum)&0x00ff);
		for(int k=0; k<IHEX_BYTES; k++) {   // convert 16 raw bytes into 32 ascii characters
      ctohd(&tmpLineBuff[ndx], intLineBuff[k]);
      ndx+=2;
		}
    ctohd(&tmpLineBuff[ndx], (chksum&0x00FF));
    ndx+=2;
    tmpLineBuff[ndx++]='\n';
    tmpLineBuff[ndx]='\0';      // ensures null termination
    Addr+=IHEX_BYTES;
		FilePutS(&tmpLineBuff[0], ndx, file);
	} // fullBlk lines
	chksum=0;
	if(partBlk>0) {           // there could be a evenly divisible number of bytes
		for(int j=0; j<partBlk; j++) {
			intLineBuff[j]=*(src++);
			chksum+=intLineBuff[j];
		}   // get all our bytes
    ndx=0;
    tmpLineBuff[ndx++]=':';
    ctohd(&tmpLineBuff[ndx], partBlk&0x00FF);
    ndx+=2;
    ctohd(&tmpLineBuff[ndx], ((Addr>>8)&0x00FF));
    ndx+=2;
    ctohd(&tmpLineBuff[ndx], (Addr&0x00FF));
    ndx+=2;
    ctohd(&tmpLineBuff[ndx], recType&0x00FF);
    ndx+=2;
    chksum+=(partBlk+(Addr>>8)+(Addr&0x00FF)+recType);
		chksum=((0-chksum)&0x00ff);
		for(int k=0; k<partBlk; k++) {   // convert 16 raw bytes into 32 ascii characters
      ctohd(&tmpLineBuff[ndx], intLineBuff[k]);
      ndx+=2;
    }
    ctohd(&tmpLineBuff[ndx], (chksum&0x00FF));
    ndx+=2;
    tmpLineBuff[ndx++]='\n';
    tmpLineBuff[ndx]='\0';    // ensure null-termination
		FilePutS(&tmpLineBuff[0], ndx, file);
	} // if(partBlk)
	return(1);  // no error code
}
//
// this is an insertion list sort. The elements of the symbol table remain in place and
// a sorted list of pointers is created which is used to
int sortSymbols(void) {
  int i, j, vc=0, err=false, inserted, ts;
  int strcmpCount=0;

  longestSym=numSorted=0;
  if(symCount<1) {return(false);}               // not an error, but nothing to sort
  for(i=0; i<symCount; i++) {                   // this will loop once, to process each symbol
    ts=strlen(&(Symbols[i].name[0]));
    longestSym=(ts>longestSym)?(ts):(longestSym); // used to "pretty print" symbol table
    inserted=false;
    if(i==0) {                                  // kickstart first element (nothing to match the first one to)
      Sort[0]=&(Symbols[0]);
      inserted=true;
      numSorted=1;
      continue;
    }
    for(j=0; j<numSorted; j++) {                // this is how insertion point for each symbol in sorted list is located
      if(sortNumbers!=false) {vc=((Sort[j]->value)<(Symbols[i].value))?(-1):(0);}
      else {vc=strcmp(&(Sort[j]->name[0]), &Symbols[i].name[0]);}
      ++strcmpCount;
      if(sortReverse==0) {if(vc<0) {continue;}} // insert if >= for ascending alphabetical
      else {if(vc>=0) {continue;}}
      for(int k=numSorted; k>j; k--) {          // start at list end and move downward to insertion point. (numSorted is a count, not an index, so it is index+1)
        Sort[k]=Sort[k-1];                      // move all at and above insertion point up one
      }
      Sort[j]=&(Symbols[i]);
      ++numSorted;
      inserted=true;
      break;
    } // for(j)
    if(inserted!=true) {    // if unused, it is last on list (bigger than all others sorted), so clip to end of array
      Sort[numSorted]=&(Symbols[i]);
      ++numSorted;
    }
  } // for(i)
  return(err);    // return error value
}
//
int csrcFile(const uchar* src, int sz) {
  FILE *file;
  int rows, lastrow, ndx=0;
  uchar buff[MAX_FILE_NAME]="";

  rows=sz/CSRC_COLS;
  lastrow=sz%CSRC_COLS;
  file = FileOpen(&csrcfname[0], FILE_WRITE);
  if(file==NULL) {
    PRINTF("Could not create file %s.\n", &csrcfname[0]);
    return(1);
  }
  SPRINTF((char *)&buff[0], MAX_FILE_NAME, "//\n#define C_SRC_SIZE %d\n//\nchar CS_Array[C_SRC_SIZE] = {\n", sz);
  FilePutS(&buff[0], strlen((char *)&buff[0]), file);    // array start write
  if(rows>0) {
    for(int i=0; i<rows; i++) {
      SPRINTF((char *)&buff[0], MAX_FILE_NAME, " {0x%02X}, {0x%02X}, {0x%02X}, {0x%02X}, {0x%02X}, {0x%02X}, {0x%02X}, {0x%02X},\n",
        src[ndx]&0x00FF, src[1+ndx]&0x00FF, src[2+ndx]&0x00FF, src[3+ndx]&0x00FF,
        src[4+ndx]&0x00FF, src[5+ndx]&0x00FF, src[6+ndx]&0x00FF, src[7+ndx]&0x00FF);
      ndx+=CSRC_COLS;
      FilePutS(&buff[0], strlen((char *)&buff[0]), file);    // rows write
    } // for(i)
  } // if(rows)
  if(lastrow>1) {
    for(int i=0; i<(lastrow-1); i++) {
      SPRINTF((char *)&buff[0], MAX_FILE_NAME, " {0x%02X},", src[ndx++]&0x00FF);
      FilePutS(&buff[0], strlen((char *)&buff[0]), file);    // last row-1 write
    } // for(i)
  } // if(lastrow>1)
  if(lastrow>0) {
    SPRINTF((char *)&buff[0], MAX_FILE_NAME, " {0x%02X}", src[ndx]&0x00FF);
    FilePutS(&buff[0], strlen((char *)&buff[0]), file);    // last row item write
  } // if(lastrow>0)
  SPRINTF((char *)&buff[0], MAX_FILE_NAME, "\n};\n");
  FilePutS(&buff[0], strlen((char *)&buff[0]), file);    // array closing write
  FileClose(file);
  return(0);
}
//
int srecFile(const uchar *src, int sz, int baseAddr) {
  FILE *file;
  uchar buff[MAX_FILE_NAME]="";
  uchar c;
  int chksum;
  int rowct=sz/SREC_BYTES;
  int lastrow=sz%SREC_BYTES;
  int offset=0;

  file = FileOpen(&srecfname[0], FILE_WRITE);
  if(file==NULL) {
    PRINTF("Could not create file %s.\n", &csrcfname[0]);
    return(1);
  }
  for(int i=0; i<rowct; i++) {                          // this will be all the whole rows
    buff[0]='S';                                        // record intro
    buff[1]='1';                                        // record type
    ctohd(&buff[2], SREC_BYTES+3);                      // byte count: address(2), data(32), checksum(1) ; each byte generates 2 ascii digits
    if(CF.bigEndian!=true) {
      ctohd(&buff[4], ((baseAddr+offset)>>8)&0x00FF);     // address high (big endian)
      ctohd(&buff[6], (baseAddr+offset)&0x00FF);          // address low (big endian)
    }
    else {
      ctohd(&buff[4], (uchar)(baseAddr+offset));                 // address low (little endian)
      ctohd(&buff[6], (uchar)((baseAddr+offset)>>8)&0x00FF);    // address high (little endian)
    }
    chksum=0;
    for(int j=0; j<SREC_BYTES; j++) {
      c=*(src+j+offset);
      chksum+=c;
      ctohd(&buff[(j*2)+8], c);
    } // for(j)
    ctohd(&buff[8+(2*SREC_BYTES)], (0-chksum)&0x00FF);
    buff[10+(2*SREC_BYTES)]='\n';                     // null terminator not needed
    FilePutS(&buff[0], 11+(2*SREC_BYTES), file);      // array start write
    offset+=SREC_BYTES;
  } // for(i)
  if(lastrow!=0) {                                      // partial row, or could be empty if block size is an even multiple of SREC_BYTES
    buff[0]='S';                                        // record intro
    buff[1]='1';                                        // record type
    ctohd(&buff[2], (lastrow+3)&0x00FF);                // byte count: address(2), data(x), checksum(1) ; each byte generates 2 ascii digits
    if(CF.bigEndian!=false) {
      ctohd(&buff[4], ((baseAddr+offset)>>8)&0x00FF);     // address high (big endian)
      ctohd(&buff[6], (baseAddr+offset)&0x00FF);          // address low (big endian)
    }
    else {
      ctohd(&buff[4], (uchar)(baseAddr+offset));                 // address low (little endian)
      ctohd(&buff[6], (uchar)((baseAddr+offset)>>8)&0x00FF);    // address high (little endian)
    }
    chksum=0;
    for(int j=0; j<lastrow; j++) {
      c=*(src+j+offset);
      chksum+=c;
      ctohd(&buff[(j*2)+8], c);
    } // for(j)
    ctohd(&buff[8+(2*lastrow)], (0-chksum)&0x00FF);
    buff[10+(2*lastrow)]='\n';                     // null terminator not needed
    FilePutS(&buff[0], 11+(2*lastrow), file);      // array last row write
    offset+=lastrow;
  }
  // S9 here
  FilePutS((uchar *)"S9030000FC\n", 11, file);      // array final line write

return(0);
}
//
////////////////////////////////////////// Expression Evaluator ///////////////////////////////////////////////////////////////////
//
int evalExpr(uchar *buff, int *val) {
  uchar c;
  int result=0, rt=0, err=false;

  for(int i=0; i<MAX_PAREN; i++) {VS[i].valCt=VS[i].L=VS[i].M=VS[i].Lop=VS[i].Rop=0;}
  if(buff==NULL) {
    lineError((uchar *)"Required expression missing.\n");
    *val=0;
    return(0);
  }
  while((c=*(buff))!='\0') {                             // just a peek, a pointer increment needs to happen before loop bottom
    switch (c) {
      case '@':
        hadAtSign=true;
        ++buff;
        break;
      case '#':
        if(CF.hashImmed!=false) {
        immedMode=true;
        ++buff;
        break;
        }     // may fall thru to indicate hex number by design if hashImmed mode is false
    case '$':                                            // alternate hex number designators
      ++buff;                                            // skip over the one character
      buff = processHex(buff, &result);                  // note there was not a character skipped here, and pointer is adjusted
      stackValue(result);
      break;
    case '0':                                            // leading zero, interpret this as octal or hex
      rt=testPostfix(buff);
      if(rt!=false) {
        if(rt==ISHEX) {
          buff = processHex(buff, &result);              // note pointer is adjusted afterward
          ++buff;                                        // this jumps over post-fix designator
        }
        if(rt==ISOCTAL) {
          buff = processOctal(buff, &result);            // note pointer is adjusted afterward
          ++buff;                                        // this jumps over post-fix designator
        }
        if(rt==ISBINARY) {
          buff=processBinary(buff, &result);            // note pointer is adjusted afterward
          ++buff;                                       // this jumps over post-fix designator
          }
        stackValue(result);
        break;
      }
      if ((*(buff+1)=='x')||(*(buff+1)=='X')) {
        buff+=2;                                          // skip over the 0 and the X
        buff=processHex(buff, &result);                   // note pointer is post adjusted
      }
      else {
        if ((*(buff + 1) == 'b') || (*(buff + 1) == 'B')) {
          buff+=2;                                      // skip over the 0 and the B
          buff=processBinary(buff, &result);            // note pointer is post adjusted
        }
        else {
          buff = processOctal(buff, &result);             // this is the 0100 form - starts with 0
        }                                                 // note pointer is post adjusted but no characters skipped
      }
      stackValue(result);
      break;
    case '1':                                              // interpreted as decimal (check '1' for binary postfix)
      rt=testPostfix(buff);
      if(rt==ISBINARY) {                                // if it's not binary, fall through for decimal default
        buff = processBinary(buff, &result);            // note pointer is adjusted afterward
        ++buff;
        stackValue(result);
        break;
      }
    case '2': case '3': case '4':               
    case '5': case '6': case '7': case '8': case '9':
      buff = processDecimal(buff, &result);               // note there was not a character skipped here, and pointer is adjusted
      stackValue(result);
      break;
    case 'A': case 'a':                                   // these might be the start of an A() wrapped expression
      if((*(buff+1)=='(')||((*(buff+1)=='.')&&((*(buff+2)=='1')||(*(buff+2)=='0'))&&(*(buff+3)=='('))) { // must be A(  A.0(  or A.1(
        rt=handleA(buff, &result);
        *val=result;                                      // fetchResult() already called in handleA()
        return(rt);
      }                                                 // here there is not a proper A() expression, so it falls through with the other letters
    case '_': case '.':                                 // alpha (means a symbol start). period added for directives
    case 'B': case 'C': case 'D': case 'E':
    case 'F': case 'G': case 'H': case 'I': case 'J':
    case 'K': case 'L': case 'M': case 'N': case 'O':
    case 'P': case 'Q': case 'R': case 'S': case 'T':
    case 'U': case 'V': case 'W': case 'X': case 'Y':
    case 'Z':
    case 'b': case 'c': case 'd': case 'e':
    case 'f': case 'g': case 'h': case 'i': case 'j':
    case 'k': case 'l': case 'm': case 'n': case 'o':
    case 'p': case 'q': case 'r': case 's': case 't':
    case 'u': case 'v': case 'w': case 'x': case 'y':
    case 'z':
      buff = processSymbol(buff, &result);              // note there was not a character skipped here
      stackValue(result);
      break;
    case '>':
      if(*(buff+1)==c) {                       // needs to be two consecutively
        buff+=2;
        stackOp(SHR);
        }
      else {
        if(*(buff+1)=='=') {
          buff+=2;
          stackOp(GTE);
          }
          else {
          ++buff;                                       // so this is not an endless loop
          stackOp(c);
          }
      }
      break;    
    case '<':                                           // only when used as >> or <<
      if(*(buff+1)==c) {                         // needs to be two of the same consecutively
        buff+=2;
        stackOp(SHL);
        }
      else {
        if(*(buff+1)=='=') {
          buff+=2;
          stackOp(LTE);
          }
          else {
          ++buff;                                       // so this is not an endless loop
          stackOp(c);
          }
      }
      break;
    case '=':
        if(*(buff+1)=='=') {
          buff+=2;
          stackOp(ISEQ);
          }
          else {
          ++buff;                                       // so this is not an endless loop
          lineError((uchar *)"Assignment (=) not available, did you mean equality '=='?.\n");
          }
      break;
    case '!':                                          // not
        if(*(buff+1)=='=') {
          buff+=2;
          stackOp(NOTEQ);
          }
          else {
          ++buff;                                       // so this is not an endless loop
          stackOp((uint)c);
          }
      break;
    case '&':                                           // logical AND
      if(*(buff+1)=='&') {
        buff+=2;
        stackOp(LOGAND);
      }
      else {
        ++buff;                                       // so this is not an endless loop
        stackOp((uint)c);
      }
      break;
    case '|':                                           // logical OR
      if(*(buff+1)=='|') {
        buff+=2;
        stackOp(LOGOR);
      }
      else {
        ++buff;                                       // so this is not an endless loop
        stackOp((uint)c);
      }
      break;
    case '*':                                           // this is a fall-thru by design
      if(CF.starSwap!=false) {
        ++buff;
        stackValue(PC);
        break;
      } // else falls through as op
    case '~': case '/': case '+':  case '-':           // remaining supported math ops
    case '^': case '%':
      ++buff;
      stackOp((uint)c);
      break;
    case '(':
      ++buff;
      parenMode=true;                                   // this resets false every line
      openParen();
      break;
    case ')':
      ++buff;
      closeParen();
      break;
    case '\'': case '\"':
      ++buff;
      break;
    default:
      sprintf_s((char *)&errBuff[0], MAX_LINE_LEN, "Unhandled character %c in expression.\n", c);   // error
      lineError(&errBuff[0]);
      ++buff;                           // increment pointer so this is not an endless loop, but character purpose unknown
      break;
    } // switch
  } // while
  *val=fetchResult();                  // store result using passed int pointer
  return(err);
}
//
int stackValue(int val) {     // assumed zero version
   int lp, rp, tempv;

  if((VS[plvl].valCt==0)&&(VS[plvl].Lop==0)) {  // no vals or ops
    VS[plvl].L=val;
    VS[plvl].valCt=1;
    return(0);
  }
  if((VS[plvl].valCt==0)&&(VS[plvl].Lop!=0)) {  // no val plus one op (unary)
    VS[plvl].L=0;       // assumed zero
    VS[plvl].M=val;
    VS[plvl].valCt=2;
    return(0);
  }
  if((VS[plvl].valCt==1)&&(VS[plvl].Lop!=0)&&(VS[plvl].Rop==0)) {  // one val plus one op
    VS[plvl].M=val;
    VS[plvl].valCt=2;
    return(0);
  }
  if((VS[plvl].valCt==1)&&(VS[plvl].Lop!=0)&&(VS[plvl].Rop!=0)) {  // one val plus two ops (unary)
    VS[plvl].M=0;     // assumed zero
    VS[plvl].valCt=2;
    return(0);
  }
  if((VS[plvl].valCt==2)&&(VS[plvl].Lop!=0)&&(VS[plvl].Rop!=0)) {  // two vals plus two ops (normal full clause)
    lp=findPriority(VS[plvl].Lop);
    rp=findPriority(VS[plvl].Rop);
    if(lp>=rp) {
      tempv=valueMath(VS[plvl].L, VS[plvl].Lop, VS[plvl].M);      // collapse to single value      (L->R evaluation order)
      VS[plvl].L=valueMath(tempv, VS[plvl].Rop, val);             // (L->R order)
    }
    else {
      tempv=valueMath(VS[plvl].M, VS[plvl].Rop, val);             // collapse to single value   (prioritized evaluation order)
      VS[plvl].L=valueMath(VS[plvl].L, VS[plvl].Lop, tempv);      // (R->L order)
    }
    VS[plvl].M=VS[plvl].Lop=VS[plvl].Rop=0;                  // clear entries
    VS[plvl].valCt=1;                                        // set counter to one
    return(0);
  }
  lineError((uchar *)"Unusable expression format.\n");      // all other cases are errors
  return(1);
}
//
int findPriority(int op) {
  switch(op) {
    case '*': case '~': case '/':
      {return(10);}                   // MD (includes swapstar alternate multiply)
    case '+': case '-':
      {return(9);}                    // AS
    case SHR: case SHL:
      {return(8);}
    case '<': case '>': case LTE: case GTE:
      {return(7);}
    case ISEQ: case NOTEQ:
      {return(6);}
    case '&':     {return(5);}
    case '^':     {return(4);}
    case '!':     {return(3);}
    case LOGAND:  {return(2);}
    case LOGOR:   {return(1);}
    } // switch
  return(0);                          // all else (should not be if expression evaluator properly setup)
}
//
int stackOp(uint op) {     // assumed zero version
  if((VS[plvl].valCt==0)&&(VS[plvl].Lop==0)&&(VS[plvl].Rop==0)) {  // clean deck, so unary op, assume zero
    VS[plvl].L=0;
    VS[plvl].Lop=op;
    VS[plvl].valCt=1;
    return(0);
    }
  if((VS[plvl].valCt==1)&&(VS[plvl].Lop==0)) {         // one value, no op, normal fill
    VS[plvl].Lop=op;
    return(0);
  }
  if((VS[plvl].valCt==1)&&(VS[plvl].Lop!=0)&&(VS[plvl].Rop==0)) {  // one value, two consecutive ops, assume zero
    VS[plvl].M=0;
    VS[plvl].Rop=op;
    VS[plvl].valCt=2;
    return(0);
  }
  if((VS[plvl].valCt==2)&&(VS[plvl].Lop!=0)&&(VS[plvl].Rop==0)) {  // two values, one op, normal fill
    VS[plvl].Rop=op;
    return(0);
  }
// other variants are errors
  lineError((uchar *)"Unusable expression format.\n");      // all other cases are errors
  return(1);
}
//
int fetchResult(void) {
  if(plvl!=0) {
    lineError((uchar *)"Not enough closing parentheses in expression.\n");
    plvl=0;
    }
  if((VS[plvl].valCt==2)&&(VS[plvl].Lop!=0)) { // unfinished math; ignore any possible second op
    VS[plvl].L=valueMath(VS[plvl].L, VS[plvl].Lop, VS[plvl].M);
  }
  return(VS[plvl].L);   // possibly not a complete result on any error, but something must be returned
}
//
int openParen() {     // assumed zero version
  if((1+plvl)>MAX_PAREN) {
    sprintf_s((char *)&errBuff[0], MAX_LINE_LEN, "Too many opening parentheses.");
    errReport();
    return(1);
  }
  ++plvl;
  VS[plvl].valCt=VS[plvl].L=VS[plvl].Lop=VS[plvl].M=VS[plvl].Rop=0;
  return(0);
}
//
int closeParen() {    // assumed zero version
  int tval;

  if(plvl<1) {
    sprintf_s((char *)&errBuff[0], MAX_LINE_LEN, "Too many closing parentheses.");
    errReport();
    return(1);
  }
  if((VS[plvl].valCt==0)&&(VS[plvl].Lop==0)&&(VS[plvl].Rop==0)) {
    --plvl;         // underflow checked at top
    return(0);
  }
  if((VS[plvl].valCt<2)&&(VS[plvl].Lop!=0)) {    // prior math left operators unconsumed
    lineError((uchar *)"Orphaned operators remain in parenthesized expression clause.\n");
    --plvl;         // underflow checked at top
    return(1);
    }
  if((VS[plvl].valCt==2)&&(VS[plvl].Lop!=0)&(VS[plvl].Rop==0)) {    // two terms, one op
    tval=valueMath(VS[plvl].L, VS[plvl].Lop, VS[plvl].M);           // resolve left half to one value
    --plvl;               // underflow checked at top
    stackValue(tval);
    return(0);
  }
  if((VS[plvl].valCt==1)&&(VS[plvl].Lop==0)&&(VS[plvl].Rop==0)) {    // fully resolved, single term
    tval=VS[plvl].L;
    --plvl;               // underflow checked at top
    stackValue(tval);
    return(0);
  }
// other variants are errors
  lineError((uchar *)"Parenthesized clause is incomplete.\n");      // all other cases are errors
  --plvl;     // underflow already tested for
  return(1);
}
//
int testPostfix(uchar *buff) {
  uchar c;
  int ctr=0;
  uchar *p=buff;    // copy to use for binary postfix check

  while(true) {     // test just for binary so a hex B digit doesn't swallow postfix B designator
    c=*p;
    if((c=='\0')||(c=='\n')) {break;}     // ran off end-of-line, will return false, because no B
    if(((c>='0')&&(c<='1'))||(c=='_')) {
      if(c!='_') {++ctr;}                 // actual digit count
      ++p;
      continue;
      }
    if(ctr==1) {return(false);}               // prevents 0x or 0q or 0b misinterpretation as single-digit postfix
    if((ctr>=8)&&((c=='B')||(c=='b'))) {return(ISBINARY);}
    break;          // not binary postfix character, rerun for hex/octal
  }
  ctr=0;      // reset for a new pass
  while(true) {
    c=*buff;
    if((c=='\0')||(c=='\n')) {break;}     // ran off end-of-line, will return false, because no H, O or Q
    if(((c>='0')&&(c<='9'))||((c>='A')&&(c<='F'))||((c>='a')&&(c<='f'))||(c=='_')) {
      if(c!='_') {++ctr;}   // actual digit count
      ++buff;
      continue;
      }
    if(ctr==1) {return(false);}               // prevents 0x or 0q misinterpretation as single-digit postfix
    if((c=='H')||(c=='h')||(c=='X')||(c=='x')) {return(ISHEX);}
    if((c=='O')||(c=='o')||(c=='Q')||(c=='q')) {return(ISOCTAL);}
    break;          // not an implemented postfix character (will return false)
  }
//  PRINTF("testPostFix notBin=%d ctr=%d c=%d\n", notBin, ctr, c);
  return(false);
}
//
int valueMath(int LH, uint op, int RH) {
	switch (op) {
	case '+':
		return(LH + RH);
	case '-':
		return(LH - RH);
	case '/':
		if (RH == 0) {
			sprintf_s((char *)&errBuff[0], MAX_LINE_LEN, "ERR: Division by zero attempted.");
			return(errReport());
		}
		return(LH / RH);
	case '%':
		if (RH == 0) {
			sprintf_s((char *)&errBuff[0], MAX_LINE_LEN, "ERR: Division by zero attempted in modulo operation.");
			return(errReport());
		}
		return(LH % RH);
	case '*':
  case '~':                       // alternative usable when optioned to use * for HERE (this PC location)
		return(LH * RH);
	case '>':                 // logical GT
    return(LH > RH);
	case SHR:
		return(LH >> RH);
	case '<':
    return(LH < RH);        // logical LT
	case SHL:
		return(LH << RH);
  case GTE:
		return(LH >= RH);
  case LTE:
		return(LH <= RH);
  case ISEQ:
		return(LH == RH);
  case NOTEQ:
		return(LH != RH);
  case LOGAND:
    return(LH && RH);       // logical AND
  case LOGOR:
    return(LH || RH);       // logical OR
	case '&':     
		return(LH & RH);        // bitwise AND
	case '|':
		return(LH | RH);        // bitwise OR
	case '^':
		return(LH ^ RH);        // bitwise XOR
  case '!': return(!RH);          // unary NOT operation
	default:
    // thi shouldn't happen if parser setup properly
		sprintf_s((char *)&errBuff[0], MAX_LINE_LEN, "Unavailable math operator %c encountered.\n", op);
		lineError(&errBuff[0]);
		break;
	} // switch
	return(0);
}
//
// these processXX routines need to extract only valid characters
uchar *processSymbol(uchar *buff, int *result) {
	int vv = 0;
	int rt, slen;
	char c;
	uchar thisField[MAX_NAME+1]="";

	slen = 0;
	while((c=buff[slen])!=0) {
		if((c=='.')||(c=='_')||((c>='0')&&(c<='9'))||((c>='A')&&(c<='Z'))||((c>='a')&&(c<='z'))) {  // only valid symbol characters (period added)
			thisField[slen++]=c;
			thisField[slen]='\0';     // null terminate
		}
		else {break;}
	}
	if((rt=matchPredef(&thisField[0]))!=0) {          // predefined symbol, takes precedence
		vv=CF.PDEF[rt-1].value;
		if(vv==LOCATION_FLAG) {vv=PC;}                 // PC holds current assembly address
    if(vv==X_REG_FLAG) {indexXMode=true;}           // X
    if(vv==Y_REG_FLAG) {indexYMode=true;}           // X
    if(vv==A_REG_FLAG) {AB_RegVal=A_REG_FLAG;}     // A
    if(vv==B_REG_FLAG) {AB_RegVal=B_REG_FLAG;}     // B
	}
	else {
		if((rt=findSym(&thisField[0]))!=0) {
      Symbols[rt-1].flags|=S_REFERENCED;    // it is being referenced here
      vv=Symbols[rt-1].value;
      if(((Symbols[rt-1].flags&(S_ISLABEL|S_DEFINED))==0)&&(pass!=0)) {
        sprintf_s((char *)&errBuff[0], MAX_LINE_LEN, "Symbol %s was never defined.\n", &Symbols[rt - 1].name[0]);
   		  errReport();
			}
		}
		else {addSymbol(&thisField[0], 0, (S_REFERENCED|S_FWDREF));}    // added but not yet defined (forward referenced), 0 for value
	}
	*result = vv;
	return(buff + slen);  // updates new parsing position
}
//
// these processXX routines need to extract only valid characters
uchar *processDecimal(uchar *buff, int *result) {
	int vv = 0;
	uchar c;

	while((c=(*buff))!='\0') {
		if(!((c>='0')&&(c<='9'))) {break;}  // not a valid decimal character
		vv=(vv*10)+(c-'0');                 // dec char conversion
		++buff;                             // only advance pointer if the character was used
	}
	*result=vv;
	return(buff);  // updates new parsing position
}
//
// these processXX routines need to extract only valid characters
uchar *processBinary(uchar* buff, int* result) {
	int vv = 0;
	char c;

	while((c=(*buff))!='\0') {
		if (!(((c>='0')&&(c<='1'))||(c=='_'))) {break;}        // not a valid binary character
		if (c!='_') {vv=(vv << 1)+(c-'0');}                   // binary char conversion (underscore skipped)
		++buff;                                                           // advance pointer if the character was used
	}
	*result = vv;
	return(buff);  // updates new parsing position
}
//
// these processXX routines need to extract only valid characters
uchar *processOctal(uchar* buff, int* result) {
	int vv = 0;
	char c;

	while((c=(*buff))!='\0') {
		if(!((c>='0')&&(c<='7'))) {break;}  // not a valid octal field character
		vv=(vv<<3)+(c&0x0007);              // octal char to nybble conversion
		++buff;                 // only advance pointer if character was used
	}
	*result = vv;
	return(buff);  // updates new parsing position
}
//
//
// these processXX routines need to extract only valid characters
uchar *processHex(uchar* buff, int* result) {
	int vv = 0;
	char c;

	while ((c = (*buff)) != '\0') {
		if (!(((c >= '0') && (c <= '9')) || ((c >= 'A') && (c <= 'F')) || ((c >= 'a') && (c <= 'f')))) { break; }  // not a valid hex field character
		vv = (vv << 4) + atoh(c);     // hex char to nybble conversion
		++buff;                       // only advance pointer if character was used
	}
	*result = vv;
	return(buff);  // updates new parsing position
}
//
// To manage A() style expressions. Routine will determin if A(), A.0() or A.1()
// were called which will guide code to yield desired result (16-bit, just low byte
// or just high byte), call evalExp() with it's own int *, adjust result and return.
// note this is called from evalExp(), so it is recursive.
//
int handleA(uchar *buff, int *result) {
  int adjust=0;
  int errRet;
  int resultRaw;

  if(*(buff+1)=='.') {    // will be A.0( or A.1( type
    adjust=*(buff+2);     // will be either '0' (low byte) or '1' (hi byte)
    buff+=3;              // moves to start of expression (open paren)
  }
  else {buff+=1;}   // it was A( for 16-bit result, move to start of expression
  errRet=evalExpr(buff, &resultRaw);  // note the int result is being intercepted
  resultRaw=fetchResult();
  resultRaw&=0x0000FFFF;              // mask out any 16-bit overflow
  if(adjust==0) {
    *result=resultRaw;          // sends value back to caller
    return(errRet);
    }
  if(adjust=='0') {resultRaw&=0x00FF;}      // make just low byte
  else {resultRaw=(resultRaw>>8)&0x00FF;}   // make lo byte from hi byte

  *result=resultRaw;          // sends value back to caller
  return(errRet);               // obtained from evalExp();
}
//