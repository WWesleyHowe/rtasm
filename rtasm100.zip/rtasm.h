/***********************************************************************************************
// Retargetable (RT) Cross-assembler
// Wesley Howe, W5ZZO 10-Apr-2023
// Supports CDP1802, MC6800, 6502 targets
// Use rtasm {source file} -T [1802|6800|6502] on command line to set target CPU
//
//  This comment block must appear in any source code that uses code presented
//  as whole or part of the Retargetable Cross-assembler source code.
//
//  This software is made available under the GNU GPL V3 license agreement.
*************************************************************************************************/
//
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <malloc.h>
//
#define SIZEOF(s) sizeof(s)/sizeof(s[0])
//
#define TARGET_6800   0
#define TARGET_1802   1
#define TARGET_6502   2
//
#define uint unsigned int
#define uchar unsigned char
//
#define DIRECT_ADD    0x10
#define INDEX_ADD     0x20
#define EXTENDED_ADD  0x30
#define B_REG_ADD40   0x40
#define B_REG_ADD10   0x10
#define B_REG_ADD01   0x01
//
#define SPRINTF sprintf_s
#define FPRINTF fprintf
#define PRINTF printf
#define PRINT  printf
#define FILE_WRITE "w"
#define true  1
#define false 0
#define ISHEX     16
#define ISOCTAL   8
#define ISBINARY  2
//
#define MAX_TNAME   8
#define MAX_BLOCK 32768
#define OUTPUT_MAX 65536
#define MAX_LINE_LEN 512
#define MAX_FILE_NAME 128
#define MAX_TOKENS 18
#define NUM_DB_TOKENS 16
#define MAX_NAME 31
#define MAX_SYMBOLS 1024
#define IHEX_BYTES  16
#define SREC_BYTES  32
#define MAX_MACROS 320
#define MAX_COL_WIDTH 31
#define MAX_SRC_NESTS 32
#define MAX_CONDITIONALS  32
#define SRC_INCLUDE   0x4000
#define SRC_MACRO     0x2000
#define NUM_MACRO_PARMS 9
#define CSRC_COLS       8
#define DEFAULT_FILL 0xFF
//
#define SHR     0x10          // >>
#define SHL     0x11          // <<
#define GTE     0x12          // >=
#define LTE     0x13          // <=
#define ISEQ    0x14          // ==
#define NOTEQ   0x15          // !=
#define LOGAND  0x16          // &&
#define LOGOR   0x17          // ||
//
// These values should be restricted to lowest byte so flags can be OR'd into upper byte (goes OPC.flags)
#define OP_DIRECTIVE  0x0001        // value field in struct passes the type
#define OP_SGL        0x0002        // 1-byte, 1-field op
#define OP_WREG       0x0003        // 1-byte, 2-field op (reg 0 - 15)
#define OP_OFFSET     0x0004        // 2-byte, 2-fields using addr offset (page offset)
#define OP_3BITS      0x0005        // 1-byte, 2 fields, 2nd field is restricted to 1 - 7 (no zero)
#define OP_IMMED      0x0006        // 2-byte, 2-field, expression is immediate
#define OP_EXTENDED   0x0007        // 3-byte, with 16-bit address word (hi then lo)
#define OP_WREG_1     0x0008        // 1-byte, 2-fields, but register limited to 1 - 15
#define OP_SGL_AB     0x0009        // 1-byte with A or B register spec
#define OP_ABMODE     0x000A        // like OP_AMODE, but reg A or B is in additional field, like ADD A instead of ADDA
#define OP_AMODE      0x000B        // 2 or 3 bytes, determined by expression flags (# or X)
#define OP_MULTA      0x000C        // uses flags in OPC.mflags for mapping allowed modes, supports many
#define OP_MULTJ      0x000D        // uses flags in OPC.mflags for mapping allowed modes, supports JMP
// and here are the flags for use in OPC.flags
#define NO_IMMED    0x008000
#define NO_DIRECT   0x004000
#define IMMED16     0x002000
#define MAYBE_AB    0x001000
//
#define NUM_PASSES      2
#define HASH_PRIME_32   0x01000193
#define HASH_OFFSET_32  0x811C9DC5
//
// flags for symbol handling
#define S_REFERENCED  0x0800
#define S_ISLABEL     0x0400
#define S_DEFINED     0x0200
#define S_MACRO       0x0100
#define S_FWDREF      0x0080
//
// these are the directive selectors, but in value field when type is OP_DIRECTIVE
// two tables exist because the directives work the same on all processors
#define DIR_EQU       0x01
#define DIR_ORG       0x02
#define DIR_DB        0x03
#define DIR_HEX       0x04
#define DIR_BIN       0x05
#define DIR_INC       0x06
#define DIR_ALIGN     0x07
#define DIR_ASCII     0x08
#define DIR_ASCIZ     0x09
#define DIR_LIST      0x0A
#define DIR_NOLIST    0x0B
#define DIR_FILLER    0x0C
#define DIR_MACRO     0x0D
#define DIR_MEND      0x0E
#define DIR_ISIF      0x0F
#define DIR_ISNIF     0x10
#define DIR_ELSE      0x11
#define DIR_ENDIF     0x12
#define DIR_CSRC      0x13
#define DIR_SREC      0x14
#define DIR_REDEF     0x15
#define DIR_DS        0x16
#define DIR_DW        0x17
#define DIR_END       0x18
//
// these are used to steer code between the Opcode handler and Directive handler routines
#define OP_TYPE       0x01
#define DIR_TYPE      0x02
//
// these are used as special values for fixed (predefined) symbols, like A, B, X, Y
#define LOCATION_FLAG 9999
#define X_REG_FLAG    9998
#define Y_REG_FLAG    9997
#define A_REG_FLAG    9996
#define B_REG_FLAG    9995
//
// bit flags used in OP_MULTA for allowed modes (goes in a short OPC.mflags)
// The value field for this will be an index (rather than value) into a supplemental table of output values
#define F_ACCUM       0x8000
#define F_IMMED       0x4000
#define F_ZEROPG      0x2000
#define F_ZEROPG_X    0x1000
#define F_ABS         0x0800
#define F_ABS_X       0x0400
#define F_ABS_Y       0x0200
#define F_INDIR_X     0x0100
#define F_INDIR_Y     0x0080
#define F_INDIR       0x0040
#define F_ZEROPG_Y    0x0020
#define F_NOA_ALL     F_IMMED|F_ZEROPG|F_ZEROPG_X|F_ABS|F_ABS_X|F_ABS_Y|F_INDIR_X|F_INDIR_Y
#define I_ACCUM       0    // used as indices for each mode to lookup opcode
#define I_IMMED       1
#define I_ZEROPG      2
#define I_ZEROPG_X    3
#define I_ABS         4
#define I_ABS_X       5
#define I_ABS_Y       6
#define I_INDIR_X     7
#define I_INDIR_Y     8
#define I_INDIR       9
#define I_ZEROPG_Y    10
//
struct sym {
  char name[MAX_NAME+1];
  uint hash;
  int value;
  int flags;
};
//
struct opc {
  const uchar name[8];
  uint        hash;
  const int   flags;    // OP_XXX to control assembly method
  const short value;    // opcode value or base value or table index
  const short mflags;   // not used on every CPU type
};
//
struct dpc {
  const uchar name[8];
  uint        hash;
  const int   flags;    // OP_XXX to control method (DIR flag)
  const short value;    // opcode value or base value
  const short pad;
};
//
struct pdef {
  const uchar name[8];
  uint  hash;
  const int     value;
};
//
struct mdef {
  int idNum;        // this value assigned at creation time and matches with sym[x].value
  uchar *textBuff;   // malloc() created buffer pointer that has a copy of the macro body text
  int slen;
};
//
struct tgt {
  uchar targetName[MAX_TNAME];
  int   targetVal;
};
//
struct txtsrc {
  int type;
  FILE *include;
  uchar  sname[MAX_FILE_NAME];
  int   linenum;
  uchar *textBuff;      // copied over from mdef struct
  int readNdx;          // tracks next read from textBuff
  int slen;
  uchar parms[NUM_MACRO_PARMS][MAX_FILE_NAME];    // replacement text passed on call (@1, @2... @9 @0)
};
//
struct vs {       // value stack
  int valCt;      // 1 or 2 operands, if three, then do some math and collapse to single value
  int L;          // Left value looks like 1*2+3
  int Lop;        // Left operation token
  int M;          // Middle value
  int Rop;        // Right operation token
};
//
struct cf {
  int targetVal;
  int bigEndian;
  int hashImmed;
  int useX_Mode;
  int starSwap;   // starSwap variable
  int branchRelative;
  struct opc *OPC;
  int numOp;
  struct pdef *PDEF;
  int numPdef;
};
  //
struct cf CF;
//
uchar macroInBuff[MAX_BLOCK];
uchar lineBuff[MAX_LINE_LEN];
uchar printBuff[MAX_LINE_LEN];
uchar errBuff[MAX_LINE_LEN];
uchar lstBuff[MAX_LINE_LEN];
uchar spareBuff[MAX_LINE_LEN];
uchar inpfname[MAX_FILE_NAME];
uchar incfname[MAX_FILE_NAME];
uchar hexfname[MAX_FILE_NAME];
uchar lstfname[MAX_FILE_NAME];
uchar binfname[MAX_FILE_NAME];
uchar csrcfname[MAX_FILE_NAME];
uchar srecfname[MAX_FILE_NAME];
uchar outBuff[OUTPUT_MAX];
uchar targetName[MAX_TNAME];
FILE *inpHandle=NULL;
FILE *lstHandle=NULL;
const char strTok[]=" \r\n\t,";     // delimiters for strtok() - space, CR, LF, TAB and comma
uchar *fntPtr;                      // placed here instead of static in findTok()
uchar fillByte=DEFAULT_FILL;
int incCount=0;
int tokenCount;
int fixedOp=0;
int fixedType=0;
int dirList;
int Origin=0;
uchar *tokens[MAX_TOKENS];
int outBytes=0;
int lineOutBytes=0;
uchar lineOutBuff[MAX_LINE_LEN];
int pass=0;
int Error=0;
int baseLineNum=0;
int hadDirField=0;
int starSwapSet=false;
int mCollect=false;
int srcDepth=0;
int suppressOutput[MAX_CONDITIONALS];      // this is reversed logic, non-zero means no output
int foundEnd=0;                            // true means shut off output
int condLvl=0;
int sortNumbers=false;
int sortReverse=false;
//
struct sym Symbols[MAX_SYMBOLS];
int symCount=0;
struct sym *Sort[MAX_SYMBOLS];
int numSorted=0;
int longestSym=0;
int numMacros=0;
int tempLabNum=0;
struct mdef MDEF[MAX_MACROS];
struct txtsrc TxtSrc[MAX_SRC_NESTS];
//
// expression analyzer
#define MAX_PAREN 16
struct vs VS[MAX_PAREN];
int plvl=0;
//
// these are for detecting specific addressing modes
int immedMode=false;
int indexXMode=false;
int indexYMode=false;
int parenMode=false;
int hadAtSign=false;
int AB_RegVal=0;
//
int PC=0;
uchar *labelSym;
uchar *oprSym;
uchar *expSym;
uchar *exp2Sym;
uchar *exp3Sym;
//
struct tgt TGT[]={
  {"1802", TARGET_1802}, {"6800", TARGET_6800}, {"6502", TARGET_6502}
};
// This is an array of definitions for directives. It is used on all processor targets.
struct dpc DPC[]={  // generic directives for all processors
  {"equ", 0, OP_DIRECTIVE, DIR_EQU}, {"org", 0, OP_DIRECTIVE, DIR_ORG}, {"db", 0, OP_DIRECTIVE, DIR_DB}, {"byte", 0, OP_DIRECTIVE, DIR_DB},
  {"hex", 0, OP_DIRECTIVE, DIR_HEX}, {"bin", 0, OP_DIRECTIVE, DIR_BIN}, {"include", 0, OP_DIRECTIVE, DIR_INC},
  {"align", 0, OP_DIRECTIVE, DIR_ALIGN}, {"ascii", 0, OP_DIRECTIVE, DIR_ASCII}, {"string", 0, OP_DIRECTIVE, DIR_ASCII},
  {"asciz", 0, OP_DIRECTIVE, DIR_ASCIZ}, {"list", 0, OP_DIRECTIVE, DIR_LIST}, {"nolist", 0, OP_DIRECTIVE, DIR_NOLIST},
  {"filler", 0, OP_DIRECTIVE, DIR_FILLER}, {"macro", 0, OP_DIRECTIVE, DIR_MACRO}, {"mend", 0, OP_DIRECTIVE, DIR_MEND},
  {"endm", 0, OP_DIRECTIVE, DIR_MEND}, {"=", 0, OP_DIRECTIVE, DIR_EQU},
  {"if", 0, OP_DIRECTIVE, DIR_ISIF}, {"ifn", 0, OP_DIRECTIVE, DIR_ISNIF}, {"else", 0, OP_DIRECTIVE, DIR_ELSE},
  {"endif", 0, OP_DIRECTIVE, DIR_ENDIF}, {"csrc",0,OP_DIRECTIVE, DIR_CSRC}, {"srec",0,OP_DIRECTIVE, DIR_SREC},
  {"redef",0,OP_DIRECTIVE, DIR_REDEF},
  {"dfb",0,OP_DIRECTIVE, DIR_DB}, {"ds",0,OP_DIRECTIVE, DIR_DS}, {"dfs",0,OP_DIRECTIVE, DIR_DS}, {"dw",0,OP_DIRECTIVE, DIR_DW},
  {"dfw",0,OP_DIRECTIVE, DIR_DW}, {"dwm",0,OP_DIRECTIVE, DIR_DW}, {"end",0,OP_DIRECTIVE,DIR_END}
  };
// The pdef structure holds reserved predefined names, mainly registers, and is thus processor specific.
struct pdef PDEF1802[]={ // 1802 processor specific
  {"R0", 0, 0}, {"R00", 0, 0}, {"R1", 0, 1}, {"R01", 0, 1},
  {"R2", 0, 2}, {"R02", 0, 2}, {"R3", 0, 3}, {"R03", 0, 3},
  {"R4", 0, 4}, {"R04", 0, 4}, {"R5", 0, 5}, {"R05", 0, 5},
  {"R6", 0, 6}, {"R06", 0, 6}, {"R7", 0, 7}, {"R07", 0, 7},
  {"R8", 0, 8}, {"R08", 0, 8}, {"R9", 0, 9}, {"R09", 0, 9},
  {"RA", 0, 10}, {"R0A", 0, 10}, {"RB", 0, 11}, {"R0B", 0, 11},
  {"RC", 0, 12}, {"R0C", 0, 12}, {"RD", 0, 13}, {"R0D", 0, 13},
  {"RE", 0, 14}, {"R0E", 0, 14}, {"RF", 0, 15}, {"R0F", 0, 15},
  {"R10", 0, 10}, {"R11", 0, 11}, {"R12", 0, 12}, {"R13", 0, 13},
  {"R14", 0, 14}, {"R15", 0, 15}, {"here", 0, LOCATION_FLAG}
};
// The opc structure holds the opcode names, base type, flags and base hex values for a specific CPU.
struct opc OPC1802[]={  // 1802 processor specific
  {"adc", 0, OP_SGL, 0x74}, {"add", 0, OP_SGL, 0xF4}, {"and", 0, OP_SGL, 0xF2}, {"dis", 0, OP_SGL, 0x71}, {"idl", 0, OP_SGL, 0x00},
  {"irx", 0, OP_SGL, 0x60}, {"ldx", 0, OP_SGL, 0xF0}, {"ldxa", 0, OP_SGL, 0x72}, {"lsdf", 0, OP_SGL, 0xCF},
  {"lsie", 0, OP_SGL, 0xCC}, {"lskp", 0, OP_SGL, 0xC8}, {"lsnf", 0, OP_SGL, 0xC7}, {"lsnq", 0, OP_SGL, 0xC5},
  {"lsnz", 0, OP_SGL, 0xC6}, {"lsq", 0, OP_SGL, 0xCD}, {"lsz", 0, OP_SGL, 0xCE}, {"mark", 0, OP_SGL, 0x79},
  {"nop", 0, OP_SGL, 0xC4}, {"or", 0, OP_SGL, 0xF1}, {"req", 0, OP_SGL, 0x7A}, {"ret", 0, OP_SGL, 0x70},
  {"sav", 0, OP_SGL, 0x78}, {"sd", 0, OP_SGL, 0xF5}, {"sdb", 0, OP_SGL, 0x75}, {"seq", 0, OP_SGL, 0x7B},
  {"shl", 0, OP_SGL, 0xFE}, {"shlc", 0, OP_SGL, 0x7E}, {"shr", 0, OP_SGL, 0xF6}, {"shrc", 0, OP_SGL, 0x76},
  {"skp", 0, OP_SGL, 0x38}, {"sm", 0, OP_SGL, 0xF7}, {"smb", 0, OP_SGL, 0x77}, {"stxd", 0, OP_SGL, 0x73},
  {"xor", 0, OP_SGL, 0xF3},
  {"adci", 0, OP_IMMED, 0x7C}, {"adi", 0, OP_IMMED , 0xFC}, {"ani", 0, OP_IMMED, 0xFA}, {"ldi", 0, OP_IMMED, 0xF8},
  {"ori", 0, OP_IMMED, 0xF9}, {"sdbi", 0, OP_IMMED, 0x7D}, {"sdi", 0, OP_IMMED, 0xFD}, {"smbi", 0, OP_IMMED, 0x7F},
  {"smi", 0, OP_IMMED, 0xFF}, {"xri", 0, OP_IMMED, 0xFB},
  {"b1", 0, OP_OFFSET, 0x34}, {"b2", 0, OP_OFFSET, 0x35}, {"b3", 0, OP_OFFSET, 0x36}, {"b4", 0, OP_OFFSET, 0x37},
  {"bdf", 0, OP_OFFSET, 0x33}, {"bn1", 0, OP_OFFSET, 0x3C}, {"bn2", 0, OP_OFFSET, 0x3D}, {"bn3", 0, OP_OFFSET, 0x3E},
  {"bn4", 0, OP_OFFSET, 0x3F}, {"bnf", 0, OP_OFFSET, 0x3B}, {"bnq", 0, OP_OFFSET, 0x39}, {"bnz", 0, OP_OFFSET, 0x3A},
  {"bq", 0, OP_OFFSET, 0x31}, {"br", 0, OP_OFFSET, 0x30}, {"bz", 0, OP_OFFSET, 0x32},
  {"dec", 0, OP_WREG, 0x20}, {"ghi", 0, OP_WREG, 0x90}, {"glo", 0, OP_WREG, 0x80}, {"inc", 0, OP_WREG, 0x10},
  {"lda", 0, OP_WREG, 0x40}, {"phi", 0, OP_WREG, 0xB0}, {"plo", 0, OP_WREG, 0xA0}, {"ldn", 0, OP_WREG_1, 0x00},
  {"str", 0, OP_WREG, 0x50}, {"sep", 0, OP_WREG, 0xD0}, {"sex", 0, OP_WREG, 0xE0},
  {"inp", 0, OP_3BITS, 0x68}, {"out", 0, OP_3BITS, 0x60},
  {"lbdf", 0, OP_EXTENDED, 0xC3}, {"lbnf", 0, OP_EXTENDED, 0xCB}, {"lbnq", 0, OP_EXTENDED, 0xC9}, {"lbnz", 0, OP_EXTENDED, 0xCA},
  {"lbq", 0, OP_EXTENDED, 0xC1}, {"lbr", 0, OP_EXTENDED, 0xC0}, {"lbz", 0, OP_EXTENDED, 0xC2}
};
//
struct pdef PDEF6800[]={   // 6800 processor specific
  {"X", 0, X_REG_FLAG}, {"A", 0, A_REG_FLAG}, {"B", 0, B_REG_FLAG}
  };
//
// OP_AMODE uses flags from expression field(s) to determine mode
// OP_ABMODE requires A or B register field, then uses extra field(s) like OP_AMODE does
struct opc OPC6800[]={  // 6800 processor specific
  {"dex", 0, OP_SGL, 0x09}, {"des", 0, OP_SGL, 0x34},  {"inx", 0, OP_SGL, 0x08}, {"ins", 0, OP_SGL, 0x31},
  {"txs", 0, OP_SGL, 0x35}, {"tsx", 0, OP_SGL, 0x30},  {"clc", 0, OP_SGL, 0x0C}, {"cli", 0, OP_SGL, 0x0E},
  {"clv", 0, OP_SGL, 0x0A}, {"sec", 0, OP_SGL, 0x0D},  {"sei", 0, OP_SGL, 0x0F}, {"sev", 0, OP_SGL, 0x0B},
  {"tap", 0, OP_SGL, 0x06}, {"tpa", 0, OP_SGL, 0x07},  {"aba", 0, OP_SGL, 0x1B}, {"clra", 0, OP_SGL, 0x4F},
  {"clrb", 0, OP_SGL, 0x5F}, {"cba", 0, OP_SGL, 0x11}, {"coma", 0, OP_SGL, 0x43},
  {"comb", 0, OP_SGL, 0x53}, {"nega", 0, OP_SGL, 0x40},  {"negb", 0, OP_SGL, 0x50}, {"daa", 0, OP_SGL, 0x19},
  {"deca", 0, OP_SGL, 0x4A}, {"decb", 0, OP_SGL, 0x5A},  {"inca", 0, OP_SGL, 0x4C}, {"incb", 0, OP_SGL, 0x5C},
  {"psha", 0, OP_SGL, 0x36}, {"pshb", 0, OP_SGL, 0x37},  {"pula", 0, OP_SGL, 0x32}, {"pulb", 0, OP_SGL, 0x33},
  {"rola", 0, OP_SGL, 0x59}, {"rolb", 0, OP_SGL, 0x59},  {"rora", 0, OP_SGL, 0x46}, {"rorb", 0, OP_SGL, 0x56},
  {"asla", 0, OP_SGL, 0x48}, {"aslb", 0, OP_SGL, 0x58},  {"asra", 0, OP_SGL, 0x47}, {"asrb", 0, OP_SGL, 0x57},
  {"lsra", 0, OP_SGL, 0x44}, {"lsrb", 0, OP_SGL, 0x54},  {"sba", 0, OP_SGL, 0x10}, {"tab", 0, OP_SGL, 0x16},
  {"tba", 0, OP_SGL, 0x17}, {"tsta", 0, OP_SGL, 0x4D},  {"tstb", 0, OP_SGL, 0x5D}, {"nop", 0, OP_SGL, 0x01},
  {"rti", 0, OP_SGL, 0x3B}, {"rts", 0, OP_SGL, 0x39}, {"swi", 0, OP_SGL, 0x3F}, {"wai", 0, OP_SGL, 0x3E},
  {"psh", 0, OP_SGL_AB, 0x36}, {"pul", 0, OP_SGL_AB, 0x32},
  {"adda", 0, OP_AMODE, 0x8B}, {"addb", 0, OP_AMODE, 0xCB},  {"adca", 0, OP_AMODE, 0x89}, {"adcb", 0, OP_AMODE, 0xC9},
  {"ldx", 0, OP_AMODE|IMMED16, 0xCE}, {"lds", 0, OP_AMODE|IMMED16, 0x8E}, {"cpx", 0, OP_AMODE|IMMED16, 0x8C},
  {"anda", 0, OP_AMODE, 0x84}, {"andb", 0, OP_AMODE, 0xC4},  {"bita", 0, OP_AMODE, 0x85}, {"bitb", 0, OP_AMODE, 0xC5},
  {"cmpa", 0, OP_AMODE, 0x81}, {"cmpb", 0, OP_AMODE, 0xC1},  {"eora", 0, OP_AMODE, 0x88}, {"eorb", 0, OP_AMODE, 0xC8},
  {"ldaa", 0, OP_AMODE, 0x86}, {"ldab", 0, OP_AMODE, 0xC6},  {"oraa", 0, OP_AMODE, 0x8A}, {"orab", 0, OP_AMODE, 0xCA},
  {"suba", 0, OP_AMODE, 0x80}, {"subb", 0, OP_AMODE, 0xC0},  {"sbca", 0, OP_AMODE, 0x82}, {"sbcb", 0, OP_AMODE, 0xC2},
  {"staa", 0, OP_AMODE|NO_IMMED, 0x87}, {"stab", 0, OP_AMODE|NO_IMMED, 0xC7}, {"stx", 0, OP_AMODE|NO_IMMED, 0xCF},
  {"sts", 0, OP_AMODE|NO_IMMED, 0xCF},
  {"tst", 0, OP_AMODE|NO_IMMED|NO_DIRECT|MAYBE_AB, 0x4D}, {"rol", 0, OP_AMODE|NO_IMMED|NO_DIRECT|MAYBE_AB, 0x4D, 0x49},
  {"ror", 0, OP_AMODE|NO_IMMED|NO_DIRECT|MAYBE_AB, 0x4D, 0x46}, {"asl", 0, OP_AMODE|NO_IMMED|NO_DIRECT|MAYBE_AB, 0x4D, 0x48},
  {"asr", 0, OP_AMODE|NO_IMMED|NO_DIRECT|MAYBE_AB, 0x4D, 0x47}, {"lsr", 0, OP_AMODE|NO_IMMED|NO_DIRECT|MAYBE_AB, 0x4D, 0x46},
  {"dec", 0, OP_AMODE|NO_IMMED|NO_DIRECT|MAYBE_AB, 0x4A}, {"neg", 0, OP_AMODE|NO_IMMED|NO_DIRECT|MAYBE_AB, 0x40},
  {"clr", 0, OP_AMODE|NO_IMMED|NO_DIRECT|MAYBE_AB, 0x4F}, {"inc", 0, OP_AMODE|NO_IMMED|NO_DIRECT|MAYBE_AB, 0x4C},
  {"com", 0, OP_AMODE|NO_IMMED|NO_DIRECT|MAYBE_AB, 0x43},
  {"jmp", 0, OP_AMODE|NO_IMMED|NO_DIRECT, 0x4E}, {"jsr", 0, OP_AMODE|NO_IMMED|NO_DIRECT, 0x8D},
  {"add", 0, OP_ABMODE, 0x8B}, {"adc", 0, OP_ABMODE, 0x89}, {"and", 0, OP_ABMODE, 0x84}, {"bit", 0, OP_ABMODE, 0x85},
  {"cmp", 0, OP_ABMODE, 0x81}, {"eor", 0, OP_ABMODE, 0x88}, {"lda", 0, OP_ABMODE, 0x86}, {"ora", 0, OP_ABMODE, 0x8A},
  {"sub", 0, OP_ABMODE, 0x80}, {"sbc", 0, OP_ABMODE, 0x82}, {"sta", 0, OP_ABMODE|NO_IMMED, 0x87},
  {"bra", 0, OP_OFFSET, 0x20}, {"bcc", 0, OP_OFFSET, 0x24}, {"bcs", 0, OP_OFFSET, 0x25}, {"beq", 0, OP_OFFSET, 0x27}, 
  {"bge", 0, OP_OFFSET, 0x2C}, {"bgt", 0, OP_OFFSET, 0x2E}, {"bhi", 0, OP_OFFSET, 0x22}, {"ble", 0, OP_OFFSET, 0x2F}, 
  {"bls", 0, OP_OFFSET, 0x23}, {"blt", 0, OP_OFFSET, 0x2D}, {"bmi", 0, OP_OFFSET, 0x2B}, {"bne", 0, OP_OFFSET, 0x26}, 
  {"bvc", 0, OP_OFFSET, 0x28}, {"bvs", 0, OP_OFFSET, 0x29}, {"bpl", 0, OP_OFFSET, 0x2A}, {"bsr", 0, OP_OFFSET, 0x8D}
};
//
struct pdef PDEF6502[]={   // 6502 processor specific predefined symbols
  {"A", 0, A_REG_FLAG}, {"X", 0, X_REG_FLAG}, {"Y", 0, Y_REG_FLAG}
  };
//
struct opc OPC6502[]={  // 6502 processor specific opcodes
  {"brk", 0, OP_SGL, 0x00}, {"clc", 0, OP_SGL, 0x18}, {"sec", 0, OP_SGL, 0x38}, {"cli", 0, OP_SGL, 0x58},
  {"sei", 0, OP_SGL, 0x78}, {"clv", 0, OP_SGL, 0xB8}, {"cld", 0, OP_SGL, 0xD8}, {"sed", 0, OP_SGL, 0xF8},
  {"nop", 0, OP_SGL, 0xEA}, {"tax", 0, OP_SGL, 0xAA}, {"txa", 0, OP_SGL, 0x8A}, {"dex", 0, OP_SGL, 0xCA},
  {"inx", 0, OP_SGL, 0xE8}, {"tay", 0, OP_SGL, 0xA8}, {"tya", 0, OP_SGL, 0x98}, {"dey", 0, OP_SGL, 0x88},
  {"iny", 0, OP_SGL, 0xC8}, {"rti", 0, OP_SGL, 0x40}, {"rts", 0, OP_SGL, 0x60}, {"txs", 0, OP_SGL, 0x9A},
  {"tsx", 0, OP_SGL, 0xBA}, {"pha", 0, OP_SGL, 0x48}, {"pla", 0, OP_SGL, 0x68}, {"php", 0, OP_SGL, 0x08},
  {"plp", 0, OP_SGL, 0x28}, {"bpl", 0, OP_OFFSET, 0x10}, {"bmi", 0, OP_OFFSET, 0x30}, {"bvc", 0, OP_OFFSET, 0x50},
  {"bvs", 0, OP_OFFSET, 0x70}, {"bcc", 0, OP_OFFSET, 0x90}, {"bcs", 0, OP_OFFSET, 0xB0}, {"bne", 0, OP_OFFSET, 0xD0},
  {"beq", 0, OP_OFFSET, 0xF0},
  // these use a table index in the value field (for table look up) and allowable mode flags in the mflags field
  // other modes may use the hex value in value field and do not use the mflags field
  {"adc", 0, OP_MULTA, 0x00, F_NOA_ALL}, {"and", 0, OP_MULTA, 0x01, F_NOA_ALL},
  {"asl", 0, OP_MULTA, 0x02, F_ACCUM|F_ZEROPG|F_ZEROPG_X|F_ABS|F_ABS_X},
  {"bit", 0, OP_MULTA, 0x03, F_ZEROPG|F_ABS}, {"cmp", 0, OP_MULTA, 0x04, F_NOA_ALL},
  {"cpx", 0, OP_MULTA, 0x05, F_IMMED|F_ZEROPG|F_ABS},
  {"cpy", 0, OP_MULTA, 0x06, F_IMMED|F_ZEROPG|F_ABS},
  {"dec", 0, OP_MULTA, 0x07, F_ZEROPG|F_ZEROPG_X|F_ABS|F_ABS_X},
  {"eor", 0, OP_MULTA, 0x08, F_NOA_ALL},
  {"inc", 0, OP_MULTA, 0x09, F_ZEROPG|F_ZEROPG_X|F_ABS|F_ABS_X},
  {"jmp", 0, OP_MULTJ, 0x0A, F_ABS|F_INDIR}, {"jsr", 0, OP_MULTA, 0x0B, F_ABS},
  {"lda", 0, OP_MULTA, 0x0C, F_NOA_ALL},
  {"ldx", 0, OP_MULTA, 0x0D, F_IMMED|F_ZEROPG|F_ZEROPG_Y|F_ABS|F_ABS_Y},
  {"ldy", 0, OP_MULTA, 0x0E, F_IMMED|F_ZEROPG|F_ZEROPG_X|F_ABS|F_ABS_X},
  {"lsr", 0, OP_MULTA, 0x0F, F_ACCUM|F_ZEROPG|F_ZEROPG_X|F_ABS|F_ABS_X},
  {"ora", 0, OP_MULTA, 0x10, F_NOA_ALL},
  {"rol", 0, OP_MULTA, 0x11, F_ACCUM|F_ZEROPG|F_ZEROPG_X|F_ABS|F_ABS_X},
  {"ror", 0, OP_MULTA, 0x12, F_ACCUM|F_ZEROPG|F_ZEROPG_X|F_ABS|F_ABS_X},
  {"sbc", 0, OP_MULTA, 0x13, F_NOA_ALL},
  {"sta", 0, OP_MULTA, 0x14, F_ZEROPG|F_ZEROPG_X|F_ABS|F_ABS_X|F_ABS_Y|F_INDIR_X|F_INDIR_Y},
  {"stx", 0, OP_MULTA, 0x15, F_ZEROPG|F_ABS|F_ZEROPG_Y},
  {"sty", 0, OP_MULTA, 0x16, F_ZEROPG|F_ZEROPG_X|F_ABS}
};
//
// table for OP_MULTA/J opcode values. OPC.value is index for row, OPC.mflags map of allowable modes.
// order is Accumulator, Immediate, Zero Page, Zero Page X, Absolute, Absolute X, Absolute Y, Indirect X, Indirect Y,
// Indirect and Zero Page Y
// the array uses 11 bytes per row, size set to 16 per row for even packing
uchar opArray6502[][16]= {
  {0x00, 0x69, 0x65, 0x75, 0x6D, 0x7D, 0x79, 0x61, 0x71, 0x00, 0x00},     // ADC 0x00 (table indices)
  {0x00, 0x29, 0x25, 0x35, 0x2D, 0x3D, 0x39, 0x21, 0x31, 0x00, 0x00},     // AND 0x01
  {0x0A, 0x00, 0x06, 0x00, 0x0E, 0x1E, 0x00, 0x00, 0x00, 0x00, 0x00},     // ASL 0x02
  {0x00, 0x00, 0x24, 0x00, 0x2C, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},     // BIT 0x03
  {0x00, 0xC9, 0xC5, 0xD5, 0xCD, 0xDD, 0xD9, 0xC1, 0xD1, 0x00, 0x00},     // CMP 0x04
  {0x00, 0xE0, 0xE4, 0x00, 0xEC, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},     // CPX 0x05
  {0x00, 0xC0, 0xC4, 0x00, 0xCC, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},     // CPY 0x06
  {0x00, 0x00, 0xC6, 0xD6, 0xCE, 0xDE, 0x00, 0x00, 0x00, 0x00, 0x00},     // DEC 0x07
  {0x00, 0x49, 0x45, 0x55, 0x4D, 0x5D, 0x59, 0x41, 0x51, 0x00, 0x00},     // EOR 0x08
  {0x00, 0x00, 0xE6, 0xF6, 0xEE, 0xFE, 0x00, 0x00, 0x00, 0x00, 0x00},     // INC 0x09
  {0x00, 0x00, 0x00, 0x00, 0x4C, 0x00, 0x00, 0x00, 0x00, 0x6C, 0x00},     // JMP 0x0A
  {0x00, 0x00, 0x00, 0x00, 0x20, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},     // JSR 0x0B
  {0x00, 0xA9, 0xA5, 0xB5, 0xAD, 0xBD, 0xB9, 0xA1, 0xB1, 0x00, 0x00},     // LDA 0x0C
  {0x00, 0xA2, 0xA6, 0x00, 0xAE, 0x00, 0xBE, 0x00, 0x00, 0x00, 0xB6},     // LDX 0x0D
  {0x00, 0xA0, 0xA4, 0xB4, 0xAC, 0xBC, 0x00, 0x00, 0x00, 0x00, 0x00},     // LDY 0x0E
  {0x4A, 0x00, 0x46, 0x56, 0x4E, 0x5E, 0x00, 0x00, 0x00, 0x00, 0x00},     // LSR 0x0F
  {0x00, 0x09, 0x05, 0x15, 0x0D, 0x1D, 0x19, 0x01, 0x11, 0x00, 0x00},     // ORA 0x10
  {0x2A, 0x00, 0x26, 0x36, 0x2E, 0x3E, 0x00, 0x00, 0x00, 0x00, 0x00},     // ROL 0x11
  {0x6A, 0x00, 0x66, 0x76, 0x6E, 0x7E, 0x00, 0x00, 0x00, 0x00, 0x00},     // ROR 0x12
  {0x00, 0xE9, 0xE5, 0xF5, 0xED, 0xFD, 0xF9, 0xE1, 0xF1, 0x00, 0x00},     // SBC 0x13
  {0x00, 0x00, 0x85, 0x95, 0x8D, 0x9D, 0x99, 0x81, 0x91, 0x00, 0x00},     // STA 0x14
  {0x00, 0x00, 0x86, 0x00, 0x8E, 0x00, 0x00, 0x00, 0x00, 0x00, 0x96},     // STX 0x15
  {0x00, 0x00, 0x84, 0x94, 0x8C, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}      // STY 0x16
 };
//
extern int main(int argc, char *argv[]);
extern void printHelp(char *pname);
extern FILE *FileOpen(uchar *name, const char *mode);
extern int FileGetS(uchar *buff, int nch, FILE *file);
extern int FilePutS(const uchar *src, int nch, FILE *file);
extern int FileClose(FILE *file);
extern void setup(void);
extern int Asm(void);
extern int errReport(void);
extern int makePass(void);
extern int processLine(void);
extern void wList(uchar *strg);
extern void printListingLine(uchar *buff);
extern int addSymbol(uchar *buff, int value, int flag);
extern void dumpSymbols(void);
extern uint hashit(const uchar *buff);
extern int findSym(uchar *buff);
extern int generateOutput(void);
extern int directiveHandler(void);
extern void copyExpStr(uchar *src, uchar *dest);
extern void dumpCode(void);
extern int processTokens(void);
extern int matchFixed(uchar *buff, int *type);
extern int strcaselesscmp(const uchar *, const uchar *);
extern int getLine(void);
extern void trimLine(void);
extern int getToks(uchar *buffIn);
extern uchar *findTok(uchar *buff, int begin);
extern int evalExpr(uchar *buff, int *val);
extern int handleA(uchar *buff, int *result);
extern int testPostfix(uchar *buff);
extern int valueMath(int LH, uint op, int RH);
extern int matchPredef(uchar* buff);
extern uchar *processSymbol(uchar *buff, int *result);
extern uchar *processDecimal(uchar *buff, int *result);
extern uchar *processBinary(uchar *buff, int *result);
extern uchar *processOctal(uchar *buff, int *result);
extern uchar *processHex(uchar *buff, int *result);
extern uchar atoh(uchar c);
extern int binToFile(const uchar *src, int sz);
extern int iHexToFile(const uchar *src, int sz, int baseAddr);
extern void ctohd(uchar *p, uchar c);
extern int iHexWriteSD(const uchar *src, int sz, FILE *file, const int baseAddr);
extern int sortSymbols(void);
extern int macroCall(int sndx, int hadlabel);
extern int csrcFile(const uchar *src, int sz);
extern int srecFile(const uchar *src, int sz, int baseAddr);
extern void lineError(uchar *txt);
extern int stackValue(int val);
extern int stackOp(uint op);
extern int fetchResult(void);
extern int openParen(void);
extern int closeParen(void);
extern int findPriority(int op);
extern int checkCpuTarget(void);
extern int testParenX(void);
