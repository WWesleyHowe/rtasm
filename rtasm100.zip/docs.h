/***********************************************************************************************
// Retargetable (RT) Cross-assembler
// Wesley Howe, W5ZZO 10-Apr-2023
// Supports CDP1802, MC6800, 6502 targets
// Use rtasm {source file} -T [1802|6800|6502] on command line to set target CPU
//
//  This comment block must appear in any source code that uses code presented
//  as whole or part of the Retargetable Cross-assembler source code.
//
//  This software is made available under the GNU GPL V3 license agreement.
*************************************************************************************************/
//
/*
Some features:
  - Two pass assembler allows for forward referenced label and symbol definitions.
  - Full CDP1802, MC6800 and 6502 instruction mnemonics and registers available.
  - Table driven code generation: one binary can do multiple target CPUs
  - 16-level prioritized expression solver supports all common math and logic operations.
  - Intel Hex, Motorola S-REC, raw binary or c-source (header style) output file formats.

The basics of the assembler are similar to other typical assemblers. There are four main things
that can be placed on each line your source file... some are optional, others may be required. These
four things are a label, an operator/mnemonic, an expression and comments (which are always optional).
Each of these must be separated from each other by tabs/spaces or commas, but you cannot put spaces or
commas within a field. Things that need to stay together, like an expression should not have any of
these characters within, the exception being quoted strings and 6502 indirect X instructions. A Linefeed
character (with or without a Carriage-return, which is ignored) ends a line (or at the file end).

Early computer programs were usually encoded and stored on a punched card, usually with a warning not to
"Fold, Bend, Spindle or Mutilate", and the analogy stuck for a while, each assembler line was called a card
at one time. There is a legacy of using fixed-field layout for assembly programs. The C language uses a
free-form style, and there seems to be no limit of programmers who will tell you you are formatting your
code poorly. This assembler merely seeks the proper elements in the proper order.

The first element to go on a line (although it is optional) is a Label. The Label either starts at the very
line beginning (leftmost column) or may have some spaces before it and have a colon character (:) placed on
the end of the name. The colon, when used, is removed before saving the label in the symbol table, it just
makes sure that the Label is properly recognized when it does not start at the first column. However, like a
belt with suspenders, you can start it in column one and include a colon on the end.

A label starts out as a location marker that can be used for branch targets or data tables. That label may
then be converted for use as the name of a macro, or it can be assigned a value using one of the built-in
directives, and this alters the label into a symbol that may be used in expressions, much like a
#define statement in a C compiler does, the main difference is there is no text substitution (not a macro),
instead the symbol is converted to a value. Symbols that are assigned a value (EQU) may be redefined, but not
labels that were only used as location targets. A word of caution: if you put a label on a line and equate
it to some other value, it is then not suitable for jump and branch operations, because it may no longer refer
to a correct code location.

There are good reasons to use a label and a symbol in an expression, such as defining memory table, or structures
that will help you organize raw data blocks. The label should reflect some part of the data area, and your symbol
can act as an offset to that to define smaller areas for variables.

Labels are optional on most source lines, but not for the EQU (equate) (or =) directive, or redefinition REDEF,
without which the directive will have no place to store the assigned value. MACRO definitions must also have a
label on the line, which will be used as the macro name.

A line may contain a label only, or a label and a comment. In that case the label gets the current value of
the PC (program counter) at that line, making it easy to use as a branch target, or a lookup table location.
When a label is used with the EQU directive the PC value is replaced with the value from the third element,
an expression. An expression is some collection of numbers, symbols and math operators that can be resolved to
a single number to be used in the code generation. There is a lot involved in expression analysis, which will be
covered in a later section, but don't worry about the expression overriding the PC value, because there is a
built in symbol (varies by CPU) that resolves to the same PC value, and can be used in an expression like HERE+4,
or *+4.

Comments are for users to make notes about what that line or code section does, etc. Formally, they come after
any (or none) of the first three elements, and start with a semi-colon ';'. Or the C-style // may be used, or
most of the time when the follow a complete assembly statement are just never looked at even without specific 
delineation. Additionally there is an 1802 comment designator, two periods (..).

Expressions:

As previously explained, expressions are a series of numbers (properly formatted), symbols (user defined or built-in) and
supported mathematic operations. Expressions are generally processed left-to-right, unless grouped with parentheses,
or changed due to operation prioritization, such as 3+2*7 being interpreted as 17, not 35, since multiplication has
a higher priority than addition. To get 35, the expression could be regrouped as (3+2)*7. Note that spaces, commas
or other "white" space will end an expression calculation (unless they are in a quoted string).

Parentheses used to group operations with an expression must be matched, that is, one closing ) for each opener (.
A full depth of sixteen levels may be used, but one of them will be below all parentheses pairs, a base formula level.
While expressions are free to begin parenthesized, ultimately the expression analyzer will resolve the groupings and
return with a single value. Internally, this will be a signed 32-bit or 64-bit (host dependent) value that will be
reduced to a 16 or 8-bit value to fit in the code. Within this larger analysis a range bit mask test could be made to
detect any overflow or determine if the answer is signed, within the expressions used in the assembler.

Supported math operations are + for addition, - for subtraction, * (or ~ for swapstar) for multiplication, / for
division (divide by zero is checked for and will throw an error), % for modulo (remainder, zero value also excepted)
<< for shift left (1<<2 will calculate 4), >> for shift right (4>>2 will give 1 for a result), & for logical AND
(1&3 will calculate as 1), | for logical OR (1|3 will yield 3) and ^ for exclusive-or (XOR), where bits that are the
same (either both zero or both 1) are flipped; (1^3 yields 0b11111101 in binary, or 0xFD hex).

Logical operators with true(1) or false (0) results are greater-or-equal >=, lesser or equal (<=), equality (==)
and inequality (!=). Note that assignment (single equals sign) is not done in an expression, but rather
via directive.

Operation priorities groupings are as follows (from highest to least):
  *   %    /      ;multiply, modulo and divide 
  +  -            ;addition and subtraction
  <<  >>          ;bit left-shift  and bit shift-right
  <   <=  >  >=   ;less than, less-or-equal, greater than, greater-or-equal
  ==   !=         ;equal or not equal
  &               ;bit-wise AND
  ^               ;bit-wise exclusive-or (XOR)
  |               ;bit-wise OR
  &&              ;logical AND
  ||              ;logical OR
On a line that has more than one character, all those are equal priority. If two operators have equal priority, they
will be ordered from left to right. Otherwise, the higher priority operation is done first. These priorities
generally follow those defined in the C language, except for those (like assignment) which available in expressions.
Assignments are done with directives such as EQU or REDEF.

Numbers are accepted and interpreted in decimal, octal, binary or hexadecimal depending on how they start. Any number
where digits 1 through 9 are first character will be parsed as decimal, which only allows digits 0 to 9. Note a
decimal number does not start with a zero, those will be either Octal, which only allows digits 0 through 7,
Binary, which only accepts the digits 0 and 1 (but does allow _ as a human-friendly separator) if the second
character is 'b' or 'B', or it must then be a hexadecimal number if the second character is actually the letter X
or x (case independent, 0x01 and 0X01 are the same), hexadecimal allows the digits 0 to 9 and the characters A to F
(upper or lower case). Hexadecimal numbers may also be designated by a prefix of $ (or # for the 1802) in keeping
with a long-standing tradition. While 0o and 0d are used by some assemblers for Octal and Decimal numbers, these are
not recognized by this assembler.

Some examples:
      0x1010, $1010, #1010, 01010H, 01010X      HEX numbers (start with 0 digit or $ or possibly # for some configurations)
      1010,   7                                 DEC number  (no leading zero, starts with 1 to 9)
      0110, 0110O, 0110Q                        OCT numbers (may not contain digits 8 or 9)
      00100110B, 0110_1001B                     BIN numbers

Symbols are recognized as a sequence of characters that starts with a letter (upper or lower case) or the characters
. (period) or _ (underscore). The remainder of the symbol may also include digits (but cannot start with a digit).
Symbols other than the predefined builtins are case-sensitive (unlike mnemonics), such that mySymbol and MySymbol
are two different symbols, and each may have different values.

The builtin symbols will be interpreted with a higher priority than any attempted definition of the same symbol. The
prebuilt symbols are R0 through RF (hexadecimal register names), R00 through R0F (case independent, synonymous with
R0 to RF), R00 to R15 (also synononyms for the 16 registers in the 1802 processor) and the name HERE (also case
insensitive), which will be interpreted as the PC value at the start of the line. This is used in place of $ or *
that are used by some other assemblers for the current assembly location, but interfere with other choices made
during the construction of this assembler's methods. That can be changed by using the -S switch on the commandline.
This changes the asterisk * to be the current PC in an expression, and uses ~ as the sign for multiplication. Fewer
predefined symbols are used for the 6800 (X, A and B) or the 6502 (A, X or Y).

Directives:

Directives are case-insensitive, and may include a period as the fist character to enhance compatibility with sources
written for other assemblers, such that EQU and .EQU are recognized as the same directive (along with the = sign).

The first directive described will be ORG (also allowed is the synonym .ORG, both case-insensitive). ORG sets the
current assembly address (the PC) to the value of the required expression. This is useful for assembling code for
placement in ROMS or loading at specific memory addresses other than the default of starting at 0.

The next is EQU (also allowed is .EQU or =), which requires a label field and an expression. It assigns the value of
the expression to the label provided, in place of the default value which would be the current program address. You
can include the current address in your expression by using the prebuilt symbol HERE (case insensitive). The equal
sign = can be used in place of EQU, provided it appears as a directive, and not in an expression. A label modified
this way will also be allowed to later be assigned a new value by using REDEF instead of EQU.

The next is DB (and .DB) which places one or up to 16 data bytes, separated by either commas or spaces directly into
the code output stream. The expression analyzer does not recognize any string or character constants, but their
numeric values can be used in the expressions. Each of the bytes can be specified in any manner that forms a valid
expression. This directive is useful for building lookup tables and other embedded constants in the assembled
program. By placing a label on the line containing this directive you can use the label in expressions for indexed
instructions or direct addressing of the data elements. While up to sixteen bytes can be inserted (per source line),
only the first 4 (or less) are shown in the listing.

You use the directive HEX to specify an Intel Hex format filename. No file will be generated without a filename, and
the assembler does not check the validity of the filename, if it does not match the operating system specifications,
it just fails to open. The filename should be enclosed in double quotes. There is an analogous directive, BIN, which
creates a raw binary file output, and also CSRC for C-source files. HEX, BIN, CSRC or any combination (including
none) may be used. Command-line switches exist for these filenames (to allow batch operation), however these
directives will overwrite any name put on the command-line.

INCLUDE, followed by a quoted filename will open and insert lines into your assembly. These files may be nested
(an include within another include) up to a total depth of 32 files (and/or macros).

ALIGN is used to add "padding" to a file so the next instruction is assembled on a specific adddress multiple, such
as an even address, or one divisible by 4, 8, 16 or even more. The default filler byte is 0xFF, chosen because for
EPROMS normally that means that byte does not require any programming. There is a directive, FILLER, that can be
used to specify a different value to use. Since we are only working with bytes for output, any expression that
evaluates to a number greater than 0xFF (or negative values) will have the upper bits removed, and only values
between 0x00 and 0xFF will be used.

Two directives, ASCII and ASCIZ exist to place character strings into the assembly. Both require a quoted string to
specify the text to insert, and the difference between these two is that ASCII places just the characters provided
into the assembly, while ASCIZ inserts an extra 0 (NULL) character at the end.

LIST and NOLIST may be used to hide listing lines. They act like switches, turning listing off or on.

IF, IFN, ELSE and ENDIF provide conditional assembly, accomplished by suppressing code output and location
incrementing, while still allowing analysis of each line to proceed. IF and IFN require a following expression,
which must evaluate to non-zero for IF to allow code generation, or to zero for IFN to allow code generation.
ELSE "flips" the gate status to the opposite of the prior condition, while ENDIF turns suppression off, no matter
what the prior state was. There is only one "gate" and the conditional state changes cannot be suppressed, meaning
if output has been suppressed, another IF or IFN will be evaluated and may change that status.

MACRO and MEND are used to define macros. Macros are saved text lines, parts of which can be altered based on
parameters given when the macro is used. Some illustration:

MacName:  MACRO
lbl\1     NOP
          BNE lbl\1
          MEND

This defines a macro named MacName (case sensitive), the body of which consists of the two lines between MACRO and
MEND. A later use of the macro would appear as:

          MacName   0a      ; this line is the invocation
lbl0a     NOP
          BNE lbl0a

Note that the MACRO and MEND directives are not saved or recalled, they just indicate and delimit the text to be
saved with the given name. The letters or numbers, or series of letters or numbers that are added when the macro is
invoked (separated by either spaces or commas) are used to insert literal text into locations marked with \1 through
\9 in the order given. In the above example the parameter 0a was used in the macro invocation line, and when those
lines were recalled and assembled the \1 (the first parameter) became instead 0a, which changed the label from
lbl\1 to lbl0a. A subsequent invocation might use 0b, which would provide a unique label name in the second usage.

Macro definitions may not be nested. You cannot define a macro with the keyword MACRO after you have already used
MACRO unless you have a MEND first. Macros may call other macros, and when they are used the lines will nest. Macros
may also use the include directive, and included files may define or call macros, up to a total depth of 32 sources.
This means just that you cannot use any more than 32 macros or includes unless some earlier ones have ended. Like a
stack, the active text source is the latest one called, and when that comes to an end (file end or last saved line)
the source definition is removed and the one that was below it now becomes the active source. At the base of this
stack is always the assembly file used when the program was started, when the end of that is reached assembly
ceases, and any output or listing files are generated.

CSRC (used with a filename) enables a file to be generated in a format usable as a char array in a C program.

Command line usage (switches are case insensitive, filenames may be case sensitive):

ASMRT sourcefilename -T target -L listingfilename -H hexfilename -B binfilename -C csrcfilename -S -N -R

The source filename is required. If a listing file is specified (-L) , the listing
filename needs to be offset by space(s) from the switch. By default, the list file
is sent to the stdout (console) and the NOLIST directive in the source is required
to suppress it. -H, -B and -C are optional output filename specifications, but if
used a filename is required to follow them.

Note that the assembler does not police path or extension data for a filename. It merely passes what has been
provided literally (minus quotes) to the operating system, and if it fails to open or creat the named
file it posts an error.

The -S switch (standalone) will enable the star swap, which is off by default
(* will be recognized as multiply instead of current location). -N changes the symbol table sort
to be by value (numbers) instead of alphabetical. -R alters the sort order to be reverse (highest first).
These switches do not have any characters that follow them.

Besides using the minus sign for switches (unix style), you may also use the forward slash for switches
(DOS style), such as /R or /S.


Many of the mnemonics have both a command and a register packed into a one byte instruction code. An example might be:   
  LDN R4
which will load a value from memory that is poined at by register 4 (of 0 to 15). The assembler recognizes multiple
operands which will evaluate to a legal register value, such as R04 or R4, or a plain 4 (decimal), 04 (which will
be interpreted as octal), $4 or 0x4, either of which are valid hexadecimal numbers. You could make a statement like
Walker:   EQU  R04 ;
and in subsequent expressions use Walker for the register, like
  STR  Walker ;
to store D at the location pointed at by R04. Nothing stops you from using 2+2 in the expression, you get the same
numeric value that is needed (more detail on expression analysis capabilities and limits will be delved into).

Processor specific guidelines:

Among the quirks of the 1802 is that branch instruction are not relative to the instruction location. A branch to
be taken replaces the low-order byte of the branch address (for short branches that is the only address byte) such
that the next instruction executed is on the same memory page as indicated by the high-order byte of the address.
This may require extra planning because branches close to the bottom or the top of a particular page have their
range limited in one direction or the other. Out-of-range branches are monitored during assembly and a warning/error
is issued.

The 6800 and 6502 branches use relative addressing, where the byte value after the opcode is treated as a signed
number, -128 to 127, and added/subtracted to the address after the two-byte instruction. So you can branch to an
address 126 bytes before the branch, or 129 after. The assembler monitors the code for an attempted branch that
is too far away, and issues a warning/error when this is detected.

Predefined Symbols, 1802 (case insensitive):

  R0      R00     R1      R01     R2      R02     R3      R03
  R4      R04     R5      R05     R6      R06     R7      R07
  R8      R08     R9      R09     RA      R0A     RB      R0B
  RC      R0C     RD      R0D     RE      R0E     RF      R0F
  R10     R11     R12     R13     R14     R15     here

These predefined symbols should not be redefined, as the assembler
will ignore the reassigned value and use the built-in value instead.

Mnemonics, 1802 (case insensitive):

  adc     add     and     dis     idl     irx     ldx     ldxa
  lsdf    lsie    lskp    lsnf    lsnq    lsnz    lsq     lsz
  mark    nop     or      req     ret     sav     sd      sdb
  seq     shl     shlc    shr     shrc    skp     sm      smb
  stxd    xor     adci    adi     ani     ldi     ori     sdbi
  sdi     smbi    smi     xri     b1      b2      b3      b4
  bdf     bn1     bn2     bn3     bn4     bnf     bnq     bnz
  bq      br      bz      dec     ghi     glo     inc     lda
  phi     plo     ldn     str     sep     sex     inp     out
  lbdf    lbnf    lbnq    lbnz    lbq     lbr     lbz
  
A definition of a mnemonic as a symbol will be flagged as an error
when the mnemonic is used. The assembler will interpret it as a macro
name, and reject it as an undefined macro.

6800 processor predefined symbols:

    X,  A,  B

6800 processor mnemonics:

  dex     des     inx     ins     txs     tsx     clc     cli
  clv     sec     sei     sev     tap     tpa     aba     clra
  clrb    cba     coma    comb    nega    negb    daa     deca
  decb    inca    incb    psha    pshb    pula    pulb    rola
  rolb    rora    rorb    asla    aslb    asra    asrb    lsra
  lsrb    sba     tab     tba     tsta    tstb    nop     rti
  rts     swi     wai     psh     pul     adda    addb    adca
  adcb    ldx     lds     cpx     anda    andb    bita    bitb
  cmpa    cmpb    eora    eorb    ldaa    ldab    oraa    orab
  suba    subb    sbca    sbcb    staa    stab    stx     sts
  tst     rol     ror     asl     asr     lsr     dec     neg
  clr     inc     com     jmp     jsr     add     adc     and
  bit     cmp     eor     lda     ora     sub     sbc     sta
  bra     bcc     bcs     beq     bge     bgt     bhi     ble
  bls     blt     bmi     bne     bvc     bvs     bpl     bsr

The 6800 has a number of instructions that are sometimes designated one way, and other time another. One
example is ADDA, which can also be used as ADD A. Either form produces the same binary output.

6502 processor predefined symbols:
  A       X       Y

6502 processor opcodes:
  brk     clc     sec     cli     sei     clv     cld     sed
  nop     tax     txa     dex     inx     tay     tya     dey
  iny     rti     rts     txs     tsx     pha     pla     php
  plp     bpl     bmi     bvc     bvs     bcc     bcs     bne
  beq     adc     and     asl     bit     cmp     cpx     cpy
  dec     eor     inc     jmp     jsr     lda     ldx     ldy
  lsr     ora     rol     ror     sbc     sta     stx     sty

*/